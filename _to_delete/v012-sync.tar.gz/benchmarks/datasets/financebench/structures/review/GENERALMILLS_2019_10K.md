# Review: GENERALMILLS_2019_10K

source: 10-K schema (semi-automatic, see structures.py) · reviewed: False

## Checklist

- [ ] Heading correctness: every entry is a real heading of this filing (no references, index
      lines, table cells)
- [ ] Heading hierarchy: Items level 1; MD&A subsections, statements, auditor's report and
      Notes level 2; individual notes level 3
- [ ] Page anchor: each page is where the heading is printed (physical page, 1-based)
- [ ] Missing sections: no Item, primary statement or note is missing
- [ ] False-positive sections: nothing listed twice or out of order
- [ ] Notes hierarchy: Note 1..N consecutive, all under "Notes to Consolidated Financial
      Statements"
- [ ] Item boundaries: each Item starts where the previous one ends

## Headings

| # | level | page | title | text on the page |
|---|---|---|---|---|
| 1 | 1 | 3 | Item 1. Business | Table of Contents PART IITEM 1 BusinessGeneral Mills, Inc. was incorporated in Delaware in 1928. The terms "General Mills," "Company," "registrant," "we," "us," and "our" mean Genera l |
| 2 | 1 | 8 | Item 1A. Risk Factors |  Act are also available on our website. ITEM 1A Risk FactorsOur business is subject to various risks and uncertainties. Any of the risks described below could materially, adversely affect our business |
| 3 | 1 | 15 | Item 1B. Unresolved Staff Comments | r acquisition-related intangible assets.ITEM 1B Unresolved Staff CommentsNone. ITEM 2 PropertiesWe own our principal executive offices and main research facilities, which are located in the Minneapoli |
| 4 | 1 | 15 | Item 2. Properties | .ITEM 1B Unresolved Staff CommentsNone. ITEM 2 PropertiesWe own our principal executive offices and main research facilities, which are located in the Minneapolis, Minnesota metropolitan area. We oper |
| 5 | 1 | 17 | Item 3. Legal Proceedings | Table of Contents ITEM 3 Legal ProceedingsWe are the subject of various pending or threatened legal actions in the ordinary course of our business. All such matters are subject t |
| 6 | 1 | 17 | Item 4. Mine Safety Disclosures | mental matters in which we are involved.ITEM 4 Mine Safety DisclosuresNone.PART IIITEM 5 Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities Ou |
| 7 | 1 | 17 | Item 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities | EM 4 Mine Safety DisclosuresNone.PART IIITEM 5 Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities Our common stock is listed on the New York S |
| 8 | 1 | 18 | Item 6. Selected Financial Data | Table of Contents ITEM 6 Selected Financial DataThe following table sets forth selected financial data for each of the fiscal years in the five-year period ended May 26, 2019: In |
| 9 | 1 | 19 | Item 7. Management's Discussion and Analysis of Financial Condition and Results of Operations | Table of Contents ITEM 7 Management's Discussion and Analysis of Financial Condition and Results of Operations EXECUTIVE OVERVIEWWe are a global packaged foods company. We develo |
| 10 | 1 | 48 | Item 7A. Quantitative and Qualitative Disclosures About Market Risk |  of anticipated or unanticipated events.Item 7A Quantitative and Qualitative Disclosures About Market RiskWe are exposed to market risk stemming from changes in interest and foreign exchange rates and |
| 11 | 1 | 50 | Item 8. Financial Statements and Supplementary Data | Table of Contents ITEM 8 Financial Statements and Supplementary DataREPORT OF MANAGEMENT RESPONSIBILITIESThe management of General Mills, Inc. is responsible for the fairness and |
| 12 | 2 | 51 | · Report of Independent Registered Public Accounting Firm | Table of Contents Report of Independent Registered Public Accounting Firm To the Stockholders and Board of DirectorsGeneral Mills, Inc.:Opinions on the Consolidated Financial Sta |
| 13 | 2 | 53 | · Consolidated Statements of Income | Table of Contents Consolidated Statements of Earnings GENERAL MILLS, INC. AND SUBSIDIARIES(In Millions, Except per Share Data) Fiscal Year 2019 2018 2017 Net sales $ 16,865.2 $ 1 |
| 14 | 2 | 54 | · Consolidated Statements of Comprehensive Income | Table of Contents Consolidated Statements of Comprehensive Income GENERAL MILLS, INC. AND SUBSIDIARIES(In Millions) Fiscal Year 2019 2018 2017 Net earnings, including earnings at |
| 15 | 2 | 55 | · Consolidated Balance Sheets | Table of Contents Consolidated Balance Sheets GENERAL MILLS, INC. AND SUBSIDIARIES(In Millions, Except Par Value) May 26, 2019 May 27, 2018 ASSETS Current assets: Cash and cash e |
| 16 | 2 | 57 | · Consolidated Statements of Cash Flows | Table of Contents Consolidated Statements of Cash Flows GENERAL MILLS, INC. AND SUBSIDIARIES(In Millions) Fiscal Year 2019 2018 2017 Cash Flows - Operating Activities Net earning |
| 17 | 2 | 58 | · Notes to Consolidated Financial Statements | Table of Contents Notes to Consolidated Financial Statements GENERAL MILLS, INC. AND SUBSIDIARIESNOTE 1. BASIS OF PRESENTATION AND RECLASSIFICATIONSBasis of PresentationOur Conso |
| 18 | 3 | 58 | · · Note 1. Basis Of Presentation And Reclassifications | nts GENERAL MILLS, INC. AND SUBSIDIARIESNOTE 1. BASIS OF PRESENTATION AND RECLASSIFICATIONSBasis of PresentationOur Consolidated Financial Statements include the accounts of General Mills, Inc. and al |
| 19 | 3 | 58 | · · Note 2. Summary Of Significant Accounting Policies | segment are on an April fiscal year end.NOTE 2. SUMMARY OF SIGNIFICANT ACCOUNTING POLICIESCash and Cash EquivalentsWe consider all investments purchased with an o riginal maturity of three months or l |
| 20 | 3 | 63 | · · Note 3. Acquisition And Divestitures | lts of operations or financial position.NOTE 3. ACQUISITION AND DIVESTITURESDuring the third quarter of fiscal 2019, we sold our La Salteña fresh pasta and refrigerated dough business in Argentina, an |
| 21 | 3 | 64 | · · Note 4. Restructuring, Impairment, And Other Exit Costsasset Impairments | ing of fiscal 2017 or of future results.NOTE 4. RESTRUCTURING, IMPAIRMENT, AND OTHER EXIT COSTSASSET IMPAIRMENTSIn fiscal 2019, we recorded a $192.6 million charge rel ated to the impairment of our Pr |
| 22 | 3 | 67 | · · Note 5. Investments In Unconsolidated Joint Ventures | rves on our Consolidated Balance Sheets.NOTE 5. INVESTMENTS IN UNCONSOLIDATED JOINT VENTURESWe have a 50 percent equity interest in Cereal Partners Worldwide (CPW), which manufactures and markets read |
| 23 | 3 | 68 | · · Note 6. Goodwill And Other Intangible Assets | Table of Contents NOTE 6. GOODWILL AND OTHER INTANGIBLE ASSETSThe components of goodwill and other intangible assets are as follows: In Millions May 26, 2019 May 27, 2018 Goodwil |
| 24 | 3 | 70 | · · Note 7. Financial Instruments, Risk Management Activities, And Fair Valuesfinancial | Table of Contents NOTE 7. FINANCIAL INSTRUMENTS, RISK MANAGEMENT ACTIVITIES, AND FAIR VALUESFINANCIAL INSTRUMENTSThe carrying values of cash and cash equivalents, rece ivables, a |
| 25 | 3 | 79 | · · Note 8. Debtnotes Payable |  who utilize these third party services.NOTE 8. DEBTNOTES PAYABLEThe components of notes payable and their respective weighted-av erage interest rates at the end of the periods were as follows: May 26 |
| 26 | 3 | 82 | · · Note 9. Redeemable And Noncontrolling Interests | cal 2020 is a $9.4 million pre-tax loss.NOTE 9. REDEEMABLE AND NONCONTROLLING INTERESTSOur principal redeemable and noncontrolling interests relate to our Yoplait SAS, Yoplait Marques SNC, Liberté Mar |
| 27 | 3 | 83 | · · Note 10. Stockholders' Equity | Table of Contents NOTE 10. STOCKHOLDERS' EQUITYCumulative preference stock of 5.0 million shares, without par value, is authorized but unissued.On May 6, 2014, our Board of Direc |
| 28 | 3 | 85 | · · Note 11. Stock Plans |  see Note 14 for additional information.NOTE 11. STOCK PLANSWe use broad-based stock plans to help ensure that manag ement's interests are aligned with those of our shareholders. As of May 26, 2019, a |
| 29 | 3 | 88 | · · Note 12. Earnings Per Share | Table of Contents NOTE 12. EARNINGS PER SHAREBasic and diluted EPS were calculated using the following: Fiscal Year In Millions, Except per Share Data 2019 2018 2017 Net earnings |
| 30 | 3 | 88 | · · Note 13. Retirement Benefits And Postemployment Benefits | nd performance share units 14.1 8.9 2.3 NOTE 13. RETIREMENT BENEFITS AND POSTEMPLOYMENT BENEFITSDefined Benefit Pension PlansWe have defined benefit pension plans covering many emp loyees in the Unite |
| 31 | 3 | 96 | · · Note 14. Income Taxes | Table of Contents NOTE 14. INCOME TAXESThe components of earnings before income taxes and after-tax earnings from joint ventures and the corresponding income taxes thereon are as |
| 32 | 3 | 100 | · · Note 15. Leases, Other Commitments, And Contingencies | terest and penalties as of May 27, 2018.NOTE 15. LEASES, OTHER COMMITMENTS, AND CONTINGENCIESOur leases are generally for warehouse space and equipment. Rent expense under all operating leases from co |
| 33 | 3 | 100 | · · Note 16. Business Segment And Geographic Information |  aled $482.6 million as of May 26, 2019.NOTE 16. BUSINESS SEGMENT AND GEOGRAPHIC INFORMATIONWe operate in the packaged foods industry. Our operating segments are as follows: North America Retail; Conv |
| 34 | 3 | 103 | · · Note 17. Supplemental Information | s 914.4 1,015.5 Total $3,787.2 $4,047.2 NOTE 17. SUPPLEMENTAL INFORMATIONThe components of certain Consolidated Balance Sheet accounts are as follows: In Millions May 26, 2019 May 27, 2018 Receivables |
| 35 | 3 | 106 | · · Note 18. Quarterly Data (Unaudited) | Table of Contents NOTE 18. QUARTERLY DATA (UNAUDITED)Summarized quarterly data for fiscal 2019 and fiscal 2018 follows: First Quarter Second Quarter Third Quarter Fourth Quarter  |
| 36 | 1 | 109 | Item 9. Changes in and Disagreements with Accountants on Accounting and Financial Disclosure | l as of the last day of our fiscal year.ITEM 9 Changes in and Disagreements With Accountants on Accounting and Financial DisclosureNone.ITEM 9A Controls and ProceduresWe, under the supervision and wit |
| 37 | 1 | 109 | Item 9A. Controls and Procedures | Accounting and Financial DisclosureNone.ITEM 9A Controls and ProceduresWe, under the supervision and with the participation of our management, including our Chief Executive Officer and Chief Financial |
| 38 | 1 | 110 | Item 9B. Other Information | counting Firm" in Item 8 of this report.ITEM 9B Other InformationNone.PART IIIITEM 10 Directors, Executive Officers and Corporate GovernanceThe information contained in the sections entitled "Proposal |
| 39 | 1 | 110 | Item 10. Directors, Executive Officers and Corporate Governance | t.ITEM 9B Other InformationNone.PART IIIITEM 10 Directors, Executive Officers and Corporate GovernanceThe information contained in the sections entitled "Proposal Number 1—Election of Directors," "Sha |
| 40 | 1 | 111 | Item 11. Executive Compensation | Table of Contents ITEM 11 Executive CompensationThe information contained in the sections entitled "Executive Compensation," "Director Compensation," and "Overseeing Risk Managem |
| 41 | 1 | 111 | Item 12. Security Ownership of Certain Beneficial Owners and Management and Related Stockholder Matters | ers is incorporated herein by reference.ITEM 12 Security Ownership of Certain Beneficial Owners and Management and Related Stockholder MattersThe information contained in the section entitled "Ownersh |
| 42 | 1 | 111 | Item 13. Certain Relationships and Related Transactions, and Director Independence | res available for grant at May 26, 2019.ITEM 13 Certain Relationships and Related Transactions, and Director IndependenceThe information set forth in the section entitled "Board Independence and Relat |
| 43 | 1 | 111 | Item 14. Principal Accountant Fees and Services | ers is incorporated herein by reference.ITEM 14 Principal Accounting Fees and ServicesThe information contained in the section entitled "Independent Registered Public Accounting Firm Fees" in our defi |
| 44 | 1 | 112 | Item 15. Exhibits and Financial Statement Schedules | Table of Contents PART IVITEM 15 Exhibits, Financial Statement Schedules 1.Financial Statements:The following financial statements are included in Item 8 of this report:Consolidated Sta |
| 45 | 1 | 116 | Item 16. Form 10-K Summary |  furnish copies to the SEC upon request.ITEM 16 Form 10-K SummaryNot Applicable. 116 |
