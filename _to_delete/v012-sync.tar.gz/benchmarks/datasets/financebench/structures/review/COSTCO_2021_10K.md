# Review: COSTCO_2021_10K

source: 10-K schema (semi-automatic, see structures.py) · reviewed: False

## Checklist

- [ ] Heading correctness: every entry is a real heading of this filing (no references, index
      lines, table cells)
- [ ] Heading hierarchy: Items level 1; MD&A subsections, statements, auditor's report and
      Notes level 2; individual notes level 3
- [ ] Page anchor: each page is where the heading is printed (physical page, 1-based)
- [ ] Missing sections: no Item, primary statement or note is missing
- [ ] False-positive sections: nothing listed twice or out of order
- [ ] Notes hierarchy: Note 1..N consecutive, all under "Notes to Consolidated Financial
      Statements"
- [ ] Item boundaries: each Item starts where the previous one ends

## Headings

| # | level | page | title | text on the page |
|---|---|---|---|---|
| 1 | 1 | 3 | Item 1. Business | ents, except as required by law. PART I Item 1—Business Costco Wholesale Corporation and its subsidiaries (Costco or the Company) began operations in 1983, in Seattle, Washington. We areprincipally en |
| 2 | 1 | 9 | Item 1A. Risk Factors | Table of Contents Item 1A—Risk Factors The risks described below could materially and adversely affect our business, financial condition and results of operations. We could also  |
| 3 | 1 | 19 | Item 1B. Unresolved Staff Comments | Table of Contents Item 1B—Unresolved Staff Comments None. Item 2—Properties Warehouse Properties At August 29, 2021, we operated 815 membership warehouses: Own Landand Building L |
| 4 | 1 | 19 | Item 2. Properties | Item 1B—Unresolved Staff Comments None. Item 2—Properties Warehouse Properties At August 29, 2021, we operated 815 membership warehouses: Own Landand Building Lease Landand/orBuilding Total United Sta |
| 5 | 1 | 19 | Item 3. Legal Proceedings | duction of certain private-label items. Item 3—Legal Proceedings See discussion of Legal Proceedings in Note 11 to the consolidated financial statements included in Item 8 of this Report. Item 4—Mine  |
| 6 | 1 | 19 | Item 4. Mine Safety Disclosures | ents included in Item 8 of this Report. Item 4—Mine Safety Disclosures Not applicable. (1) 19 |
| 7 | 1 | 20 | Item 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities | Table of Contents PART II Item 5—Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities Market Information and Dividend Policy Our c |
| 8 | 1 | 22 | Item 7. Management's Discussion and Analysis of Financial Condition and Results of Operations | Table of Contents Item 7—Management's Discussion and Analysis of Financial Conditions and Results of Operations (amounts in millions, except per share, share, membership fee, and |
| 9 | 2 | 22 | · Overview | iscussion of our results of operations. Overview We believe that the most important driver of our profitability is increasing net sales, particularly comparable sales growth. Net sales includes our co |
| 10 | 2 | 25 | · Results of Operations | Table of Contents RESULTS OF OPERATIONS Net Sales 2021 2020 2019 Net Sales $ 192,052 $ 163,220 $ 149,351 Increases in net sales: U.S. 16 % 9 % 9 % Canada 22 % 5 % 3 % Other Inter |
| 11 | 2 | 28 | · Liquidity and Capital Resources | efits, the tax rate was 26.4% for 2021. LIQUIDITY AND CAPITAL RESOURCES The following table summarizes our significant sources and uses of cash and cash equivalents: 2021 2020 2019 Net cash provided b |
| 12 | 2 | 30 | · Off-Balance Sheet Arrangements | mmercial letters of credit outstanding. Off-Balance Sheet Arrangements In the opinion of management, we have no off-balance sheet arrangements that have had or are reasonably likely to have a material |
| 13 | 2 | 30 | · Critical Accounting Estimates | cial condition or financial statements. Critical Accounting Estimates The preparation of our consolidated financial statements in accordance with U.S. generally accepted accounting principles (U.S. GA |
| 14 | 2 | 30 | · Recent Accounting Pronouncements | o our estimates have not been material. Recent Accounting Pronouncements We do not expect that any recently issued accounting pronouncements will have a material effect on our financial statements. 30 |
| 15 | 1 | 31 | Item 7A. Quantitative and Qualitative Disclosures About Market Risk | Table of Contents Item 7A—Quantitative and Qualitative Disclosures About Market Risk (amounts in millions) Our exposure to financial market risk results from fluctuations in inte |
| 16 | 1 | 33 | Item 8. Financial Statements and Supplementary Data | Table of Contents Item 8—Financial Statements and Supplementary Data REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM To the Stockholders and Board of Directors Costco Who |
| 17 | 2 | 33 | · Report of Independent Registered Public Accounting Firm | ncial Statements and Supplementary Data REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM To the Stockholders and Board of Directors Costco Wholesale Corporation: Opinion on the Consolidated Fin |
| 18 | 2 | 36 | · Consolidated Statements of Income | f Contents COSTCO WHOLESALE CORPORATION CONSOLIDATED STATEMENTS OF INCOME (amounts in millions, except per share data) 52 Weeks Ended 52 Weeks Ended 52 Weeks Ended August 29,2021 August 30,2020 Septem |
| 19 | 2 | 37 | · Consolidated Statements of Comprehensive Income | f Contents COSTCO WHOLESALE CORPORATION CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME (amounts in millions) 52 Weeks Ended 52 Weeks Ended 52 Weeks Ended August 29,2021 August 30,2020 September 1,201 |
| 20 | 2 | 38 | · Consolidated Balance Sheets | f Contents COSTCO WHOLESALE CORPORATION CONSOLIDATED BALANCE SHEETS (amounts in millions, except par value and share data) August 29,2021 August 30,2020 ASSETS CURRENT ASSETS Cash and cash equivalents |
| 21 | 2 | 39 | · Consolidated Statements of Equity | f Contents COSTCO WHOLESALE CORPORATION CONSOLIDATED STATEMENTS OF EQUITY (amounts in millions) Common Stock AdditionalPaid-inCapital AccumulatedOtherComprehensiveIncome (Loss) RetainedEarnings Total  |
| 22 | 2 | 40 | · Consolidated Statements of Cash Flows | f Contents COSTCO WHOLESALE CORPORATION CONSOLIDATED STATEMENTS OF CASH FLOWS (amounts in millions) 52 Weeks Ended 52 Weeks Ended 52 Weeks Ended August 29,2021 August 30,2020 September 1,2019 CASH FLO |
| 23 | 2 | 41 | · Notes to Consolidated Financial Statements | f Contents COSTCO WHOLESALE CORPORATION NOTES TO CONSOLIDATED FINANCIAL STATEMENTS (amounts in millions, except share, per share, and warehouse count data) Note 1—Summary of Significant Accounting Pol |
| 24 | 3 | 41 | · · Note 1. Summary of Significant Accounting Policies | e, per share, and warehouse count data) Note 1—Summary of Significant Accounting Policies Description of Business Costco Wholesale Corporation (Costco or the Company), a Washington corporation, and it |
| 25 | 3 | 50 | · · Note 2. Acquisition of Innovel | Table of Contents Note 2—Acquisition of Innovel On March 17, 2020, the Company acquired Innovel Solutions for $999, using existing cash and cash equivalents. Innovel (now known a |
| 26 | 3 | 50 | · · Note 3. Investments | lly recorded in 2020 were not material. Note 3—Investments The Company's investments were as follows: 2021: CostBasis UnrealizedGains, Net RecordedBasis Available-for-sale: Government and agency secur |
| 27 | 3 | 51 | · · Note 4. Fair Value Measurement | Table of Contents Note 4—Fair Value Measurement Assets and Liabilities Measured at Fair Value on a Recurring Basis The table below presents information regarding the Company's fi |
| 28 | 3 | 51 | · · Note 5. Debt | adjustments to these items during 2020. Note 5—Debt Short-Term Borrowings The Company maintains various short-term bank credit facilities, with a borrowing capacity of $1,050 and $967, in 2021 and 202 |
| 29 | 3 | 53 | · · Note 6. Leases | Table of Contents Note 6—Leases The tables below present information regarding the Company's lease assets and liabilities. 2021 2020 Assets Operating lease right-of-use assets $  |
| 30 | 3 | 55 | · · Note 7. Equity | Table of Contents Note 7—Equity Dividends Cash dividends declared in 2021 totaled $12.98 per share, as compared to $2.70 per share in 2020. Dividends in 2021 included a special d |
| 31 | 3 | 55 | · · Note 8. Stock-Based Compensation | ursuant to plans under SEC Rule 10b5-1. Note 8—Stock-Based Compensation The Company grants stock-based compensation, primarily to employees and non-employee directors. Grants to all executive officers |
| 32 | 3 | 57 | · · Note 9. Taxes | Table of Contents Note 9— Taxes Income Taxes Income before income taxes is comprised of the following: 2021 2020 2019 Domestic $ 4,931 $ 4,204 $ 3,591 Foreign 1,749 1,163 1,174 T |
| 33 | 3 | 60 | · · Note 10. Net Income per Common and Common Equivalent Share | Table of Contents Note 10—Net Income per Common and Common Equivalent Share The following table shows the amounts used in computing net income per share and the weighted average  |
| 34 | 3 | 60 | · · Note 11. Commitments and Contingencies |  diluted shares 444,346 443,901 442,923 Note 11—Commitments and Contingencies Legal Proceedings The Company is involved in a number of claims, proceedings and litigations arising from its business and |
| 35 | 3 | 64 | · · Note 12. Segment Reporting | Table of Contents Note 12—Segment Reporting The Company is principally engaged in the operation of membership warehouses through wholly owned subsidiaries in the U.S., Canada, Me |
| 36 | 1 | 65 | Item 9. Changes in and Disagreements with Accountants on Accounting and Financial Disclosure | Table of Contents Item 9—Changes in and Disagreements with Accountants on Accounting and Financial Disclosure None. Item 9A—Controls and Procedures Evaluation of Disclosure Contr |
| 37 | 1 | 65 | Item 9A. Controls and Procedures | counting and Financial Disclosure None. Item 9A—Controls and Procedures Evaluation of Disclosure Controls and Procedures Our disclosure controls and procedures (as defined in Rules 13a-15(e) or 15d-15 |
| 38 | 1 | 69 | Item 16. Form 10-K Summary | (c) Financial Statement Schedules—None. Item 16—Form 10-K Summary None. 69 |
