# Review: AMAZON_2017_10K

source: 10-K schema (semi-automatic, see structures.py) · reviewed: False

## Checklist

- [ ] Heading correctness: every entry is a real heading of this filing (no references, index
      lines, table cells)
- [ ] Heading hierarchy: Items level 1; MD&A subsections, statements, auditor's report and
      Notes level 2; individual notes level 3
- [ ] Page anchor: each page is where the heading is printed (physical page, 1-based)
- [ ] Missing sections: no Item, primary statement or note is missing
- [ ] False-positive sections: nothing listed twice or out of order
- [ ] Notes hierarchy: Note 1..N consecutive, all under "Notes to Consolidated Financial
      Statements"
- [ ] Item boundaries: each Item starts where the previous one ends

## Headings

| # | level | page | title | text on the page |
|---|---|---|---|---|
| 1 | 1 | 3 | Item 1. Business | able of Contents AMAZON.COM, INC. PART IItem 1.Business This Annual Report on Form 10-K and the documents incorporated herein by reference contain forward-looking statements based on expectations,esti |
| 2 | 1 | 6 | Item 1A. Risk Factors | Table of Contents Item 1A.Risk Factors Please carefully consider the following risk factors. If any of the following risks occur, our business, financial condition, operating res |
| 3 | 1 | 15 | Item 1B. Unresolved Staff Comments | Table of Contents Item 1B.Unresolved Staff Comments None.15 |
| 4 | 1 | 16 | Item 2. Properties | Table of Contents Item 2.Properties As of December 31, 2017 , we operated the following fa cilities (in thousands): Description of Use Leased SquareFootage (1) Owned Square Foota |
| 5 | 1 | 16 | Item 3. Legal Proceedings | ally in North America, Europe, and Asia.Item 3.Legal Proceedings See Item 8 of Part II, "Financial Statements and Supplementary Data—Note 7—Commitments and Contingencies—Legal Proceedings."Item 4.Mine |
| 6 | 1 | 17 | Item 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities | Table of Contents PART II Item 5.Market for the Registrant's Common Stock, Related Shareholder Mat ters, and Issuer Purchases of Equity SecuritiesMarket InformationOur common stock is tr |
| 7 | 1 | 18 | Item 6. Selected Financial Data | Table of Contents Item 6.Selected Consolidated Financial Data The following selected consolidated financial data should be read in conjunction with the consolidated financial sta |
| 8 | 1 | 19 | Item 7. Management's Discussion and Analysis of Financial Condition and Results of Operations | Table of Contents Item 7.Management's Discussion and Analysis of Financial Condition and Results of Operations Forward-Looking StatementsThis Annual Report on Form 10-K includes  |
| 9 | 1 | 33 | Item 7A. Quantitative and Qualitative Disclosures About Market Risk | Table of Contents Item 7A.Quantitative and Qualitative Disclosures About Market Risk We are exposed to market risk for the effect of interest rate changes, foreign currency fluct |
| 10 | 1 | 35 | Item 8. Financial Statements and Supplementary Data | Table of Contents Item 8.Financial Statements and Supplementary Data INDEX TO CONSOLIDATED F INANCIAL STATEMENTS Page Report of Ernst & Young LLP, Independent Registered Public A |
| 11 | 2 | 35 | · Consolidated Statements of Cash Flows | ent Registered Public Accounting Firm36 Consolidated Statements of Cash Flows37 Consolidated Statements of Operations38 Consolidated Statements of Comprehensive Income39 Consolidated Balance Sheets40  |
| 12 | 2 | 35 | · Consolidated Statements of Income | Consolidated Statements of Cash Flows37 Consolidated Statements of Operations38 Consolidated Statements of Comprehensive Income39 Consolidated Balance Sheets40 Consolidated Statements of Stockholders' |
| 13 | 2 | 36 | · Report of Independent Registered Public Accounting Firm | Table of Contents Report of Independent Registered Public Accounting Firm The Board of Directors and ShareholdersAmazon.com, Inc.Opinion on the Financial StatementsWe have audite |
| 14 | 2 | 39 | · Consolidated Statements of Comprehensive Income | Table of Contents AMAZON.COM, INC. CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME(in millions) Year Ended December 31, 2015 2016 2017Net income$ 596 $2,371 $3,033Other comprehensive income (loss |
| 15 | 2 | 40 | · Consolidated Balance Sheets | Table of Contents AMAZON.COM, INC. CONSOLIDATED BALANCE SHEETS(in millions, except per share data) December 31, 2016 2017ASSETS Current assets: Cash and cash equivalents$ 19,334 $20,522Marketable |
| 16 | 2 | 41 | · Consolidated Statements of Equity | Table of Contents AMAZON.COM, INC. CONSOLIDATED STATEMENTS OF STOCKHOLDERS' EQUITY(in millions) Common Stock Shares Amount TreasuryStock AdditionalPaid-InCapital Accumulated OtherComprehensiveInc |
| 17 | 2 | 42 | · Notes to Consolidated Financial Statements | Table of Contents AMAZON.COM, INC. NOTES TO CONSOLIDATED FINANCIAL STATEMENTSNote 1—DESCRIPTION OF BUSINESS AND ACCOUNTING POLICIESDescription of BusinessAmazon.com opened its virtual doors on th |
| 18 | 3 | 42 | · · Note 1. Description Of Business And Accounting Policies | TES TO CONSOLIDATED FINANCIAL STATEMENTSNote 1—DESCRIPTION OF BUSINESS AND ACCOUNTING POLICIESDescription of BusinessAmazon.com opened its virtual doors on the World Wide Web in July 1995. We seek to  |
| 19 | 3 | 50 | · · Note 2. Cash, Cash Equivalents, And Marketable Securities | ill adopt this ASU beginning in Q1 2018.Note 2—CASH, CASH EQUIVALENTS, AND MARKETABLE SECURITIESAs of December 31, 2016 and 2017 , our cash, cash equivalents, and marketable securities primarily consi |
| 20 | 3 | 52 | · · Note 3. Property And Equipment | Table of Contents Note 3—PROPERTY AND EQUIPMENTProperty and equipment, at cost, consisted of the following (in millions): December 31, 2016 2017Gross property and equipment (1):  |
| 21 | 3 | 52 | · · Note 4. Acquisitions, Goodwill, And Acquired Intangible Assets | llion as of December 31, 2016 and 2017 .Note 4—ACQUISITIONS, GOODWILL, AND ACQUIRED INTANGIBLE ASSETSAcquisition ActivityDuring 2015 and 2016 , we acquired certain companies for an aggregate purchase  |
| 22 | 3 | 56 | · · Note 5. Long-Term Debt | Table of Contents Note 5—LONG-TERM DEBTAs of December 31, 2017, we had $24.3 billion of unsecured senior notes outstanding (the "Notes"), including $17.0 billion of notes issued  |
| 23 | 3 | 58 | · · Note 6. Other Long-Term Liabilities | Table of Contents Note 6—OTHER LONG-TERM LIABILITIESOur other long-term liabilities are summarized as follows (in millions): December 31, 2016 2017 Long-term capital lease obliga |
| 24 | 3 | 59 | · · Note 7. Commitments And Contingencies | Table of Contents Note 7—COMMITMENTS AND CONTINGENCIESCommitmentsWe have entered into non-cancellable operating, capital, and finance leases for equipment and office, fulfillment |
| 25 | 3 | 62 | · · Note 8. Stockholders' Equity | emedies.See also "Note 10—Income Taxes."Note 8—STOCKHOLDERS' EQUITYPreferred StockWe have authorized 500 million shares of $0.01 par value preferred stock. No preferred stock was outstanding for any p |
| 26 | 3 | 64 | · · Note 9. Accumulated Other Comprehensive Loss | ance to employees is 116 million shares.Note 9—ACCUMULATED OTHER COMPREHENSIVE LOSSChanges in the composition of accumulated other comprehensive loss for 2015 , 2016 , and 2017 are as follows (in mill |
| 27 | 3 | 64 | · · Note 10. Income Taxes | net of their related income tax effects.Note 10—INCOME TAXESIn 2015 , 2016 , and 2017 , we recorded net tax provisions of $950 million , $1.4 billion , and $769 million . We have tax benefits relating |
| 28 | 3 | 68 | · · Note 11. Segment Information | imate of the range of possible outcomes.Note 11—SEGMENT INFORMATIONWe have organized our operations into three segments: North America, International, and AWS. We allocate to segment results the opera |
| 29 | 3 | 72 | · · Note 12. Quarterly Results | Note 12—QUARTERLY RESULTS (UNAUDITED)The following tables contain selected unaudited statement of operations information for each quarter of 2016 and 2017 . The |
| 30 | 1 | 73 | Item 9. Changes in and Disagreements with Accountants on Accounting and Financial Disclosure | Table of Contents Item 9.Changes in and Disagreements with Accountants On Accounting and Financial Disclosure None.Item 9A.Controls and Procedures Evaluation of Disclosure Contro |
| 31 | 1 | 73 | Item 9A. Controls and Procedures | ccounting and Financial Disclosure None.Item 9A.Controls and Procedures Evaluation of Disclosure Controls and ProceduresWe carried out an evaluation required by the Securities Exchange Act of 1934 (th |
| 32 | 1 | 77 | Item 16. Form 10-K Summary |  to a request for confidentialtreatment.Item 16.Form 10-K SummaryNone.77 |
