# Review: WALMART_2018_10K

source: 10-K schema (semi-automatic, see structures.py) · reviewed: False

## Checklist

- [ ] Heading correctness: every entry is a real heading of this filing (no references, index
      lines, table cells)
- [ ] Heading hierarchy: Items level 1; MD&A subsections, statements, auditor's report and
      Notes level 2; individual notes level 3
- [ ] Page anchor: each page is where the heading is printed (physical page, 1-based)
- [ ] Missing sections: no Item, primary statement or note is missing
- [ ] False-positive sections: nothing listed twice or out of order
- [ ] Notes hierarchy: Note 1..N consecutive, all under "Notes to Consolidated Financial
      Statements"
- [ ] Item boundaries: each Item starts where the previous one ends

## Headings

| # | level | page | title | text on the page |
|---|---|---|---|---|
| 1 | 1 | 7 | Item 1. Business | ITEM 1. BUSINESS GeneralWalmart Inc. ("Walmart," the "Company" or "we") helps people around the world save money and live better – anytime and anywhere – in ret |
| 2 | 1 | 17 | Item 1A. Risk Factors | months following theamendment or waiver.ITEM 1A.RISK FACTORS The risks described below could materially and adversely affect our business, results of operations, financial condition and liquidity. Our |
| 3 | 1 | 26 | Item 1B. Unresolved Staff Comments |  material to our business in the future.ITEM 1B.UNRESOLVED STAFF COMMENTS None.26 |
| 4 | 1 | 27 | Item 2. Properties | ITEM 2. PROPERTIES United StatesThe Walmart U.S. and Sam's Club segments comprise the Company's operations in the U.S. As of January 31, 2018 , unit counts for  |
| 5 | 1 | 31 | Item 3. Legal Proceedings | ur segments under " Item 1. Business ." ITEM 3.LEGAL PROCEEDINGS I. SUPPLEMENTAL INFORMATION: We discuss certain leg al proceedings in Note 10 to our Consolidated Financial Statements, entitled "Conti |
| 6 | 1 | 32 | Item 4. Mine Safety Disclosures | itigation plan to address the situation.ITEM 4.MINE SAFETY DISCLOSURES Not applicable.30 |
| 7 | 1 | 33 | Item 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities | PART II ITEM 5.MARKET FOR REGISTRANT 'S COMMON EQUITY, RELATED STOCKHOLDER MATTERS AND ISSUER PURCHASES OFEQUITY SECURITIESMarket for Common StockWalmart's common stock |
| 8 | 1 | 35 | Item 6. Selected Financial Data | ITEM 6. SELECTED FINANCIAL DATA Five-Year Financial Summary Walmart Inc. As of and for the Fiscal Years Ended January 31, (Amounts in millions, except per share |
| 9 | 1 | 36 | Item 7. Management's Discussion and Analysis of Financial Condition and Results of Operations | ITEM 7. MANAGEMENT'S DISCUSSI ON AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONSOverviewWalmart Inc. ("Walmart," the "Company" or "we") is engaged |
| 10 | 2 | 48 | · Contractual Obligations | Contractual Obligations The following table sets forth certain information concerning our obligations to make contractual future payments, such as debt and leas |
| 11 | 1 | 51 | Item 7A. Quantitative and Qualitative Disclosures About Market Risk | ITEM 7A. QUANTITATIVE AND QUALITATIVE DISCL OSURES ABOUT MARKET RISKMarket RiskIn addition to the risks inherent in our operations, we are exposed to certain ma |
| 12 | 1 | 53 | Item 8. Financial Statements and Supplementary Data | ITEM 8. FINANCIAL STATEMENTS AND SUPPLEMENTARY DATAConsolidated Financial Statements of Walmart Inc. (formerly "Wal-Mart Stores, Inc.")For the Fiscal Year Ended |
| 13 | 2 | 53 | · Report of Independent Registered Public Accounting Firm | nagement's Report to Our Shareholders52 Report of Independent Registered Public Accounting Firm53 Report of Independent Registered Public Accounting Firm on Internal Control over Financial Reporting54 |
| 14 | 2 | 55 | · Consolidated Balance Sheets | tementsWe have audited the accompanying consolidated balance sheets of Walmart Inc. (the Company) as of January 31, 2018 and 2017 , the related consolidatedstatements of income, comprehensive income,  |
| 15 | 2 | 57 | · Consolidated Statements of Income | Walmart Inc. Consolidated Statements of Income Fiscal Years Ended January 31, (Amounts in millions, except per share data) 2018 2017 2016Revenues: Net sales $495,761 $481,31 |
| 16 | 2 | 58 | · Consolidated Statements of Comprehensive Income | Walmart Inc. Consolidated Statements of Comprehensive Income Fiscal Years Ended January 31, (Amounts in millions) 2018 2017 2016Consolidated net income $10,523 $14,293 $15,0 |
| 17 | 2 | 61 | · Consolidated Statements of Equity | Walmart Inc. Consolidated Statements of Shareholders' Equity Accumulated Total Capital in Other Walmart (Amounts in millions)Common Stock Excess of Retained Comprehensive Sh |
| 18 | 2 | 62 | · Consolidated Statements of Cash Flows | Walmart Inc. Consolidated Statements of Cash Flows Fiscal Years Ended January 31, (Amounts in millions) 2018 2017 2016Cash flows from operating activities: Consolidated net  |
| 19 | 2 | 63 | · Notes to Consolidated Financial Statements | Walmart Inc. Notes to Consolidated Financial StatementsNote 1. Summary of Significant Accounting PoliciesGeneralWalmart Inc. (formerly "Wal-Mart Stores, Inc.") ("Walmart" or |
| 20 | 3 | 63 | · · Note 1. Summary of Significant Accounting Policies | tes to Consolidated Financial StatementsNote 1. Summary of Significant Accounting PoliciesGeneralWalmart Inc. (formerly "Wal-Mart Stores, Inc.") ("Walmart" or the "Company") helps people around the wo |
| 21 | 3 | 69 | · · Note 2. Net Income Per Common Share | Note 2. Net Income Per Common Share Basic net income per common share attributable to Walmart is based on the weighted-average common shares outstanding during  |
| 22 | 3 | 69 | · · Note 3. Shareholders' Equity | 3.29 $4.40 $4.58 Diluted 3.28 4.38 4.57 Note 3. Shareholders' EquityShare-Based CompensationThe Company has awarded share-based compensation to associates and nonemployee directors of the Company. The |
| 23 | 3 | 71 | · · Note 4. Accumulated Other Comprehensive Loss | Note 4. Accumulated Other Comprehensive Loss The following table provides the changes in the composition of total accumulated other comprehensive loss for fisca |
| 24 | 3 | 71 | · · Note 5. Accrued Liabilities |  shown in the table above is immaterial.Note 5. Accrued LiabilitiesThe Company's accrued liabilities consist of the following: As of January 31, (Amounts in millions) 2018 2017Accrued wages and benefi |
| 25 | 3 | 72 | · · Note 6. Short-term Borrowings and Long-term Debt | Note 6. Short-term Borrowings and Long-term Debt Short-term borrowings consist of commercial paper and lines of credit. Short-term borrowings at January 31, 201 |
| 26 | 3 | 75 | · · Note 7. Fair Value Measurements | Note 7. Fair Value Measurements The Company records and discloses certain financial and non-financial assets and liabilities at fair value. The fair value of an |
| 27 | 3 | 76 | · · Note 8. Derivative Financial Instruments | Note 8. Derivative Financial Instruments The Company uses derivative financial instruments for hedging and non-trading purposes to manage its exposure to change |
| 28 | 3 | 78 | · · Note 9. Taxes | Note 9. Taxes Income Before Income TaxesThe components of income before income taxes are as follows: Fiscal Years Ended January 31, (Amounts in millions)2018 20 |
| 29 | 3 | 82 | · · Note 10. Contingencies | Note 10. Contingencies Legal ProceedingsThe Company is involved in a number of legal proceedings. The Company has made accruals with respect to these matters, w |
| 30 | 3 | 84 | · · Note 11. Commitments | Note 11. Commitments The Company has long-term leases for stores and equipment. Rentals (including amounts applicable to taxes, insurance, maintenance, other op |
| 31 | 3 | 84 | · · Note 12. Retirement-Related Benefits | ch may trigger an escalation in rentals.Note 12. Retirement-Related BenefitsThe Company offers a 401(k) plan for associates in the U.S. under which eligible associates can begin contributing to the pl |
| 32 | 3 | 85 | · · Note 13. Acquisitions, Disposals and Related Items | Note 13. Acquisitions, Disposals and Related Items Other than the jet.com transaction discussed below, the Company completed certain eCommerce acquisitions duri |
| 33 | 3 | 85 | · · Note 14. Restructuring Charges | istingcash to complete this transaction.Note 14. Restructuring ChargesIn the fourth quarter of fiscal 2018, the Company announced several organizational changes to position the business for more effic |
| 34 | 3 | 86 | · · Note 15. Segments | Note 15. Segments The Company is engaged in the operation of retail, wholesale and other units, as well as eCommerce websites, located throughout the U.S., Afri |
| 35 | 3 | 87 | · · Note 16. Subsequent Event | total revenues from any single customer.Note 16. Subsequent EventDividends DeclaredOn February 20, 2018 , the Board of Directors approved the fiscal 2019 annual dividend at $2.08 per share, an increas |
| 36 | 3 | 87 | · · Note 17. Quarterly Financial Data (Unaudited) Fiscal Year Ended January 31, 2018 |  4, 2018December 7, 2018 January 2, 2019Note 17. Quarterly Financial Data (Unaudited) Fiscal Year Ended January 31, 2018 (Amounts in millions, except per share data) Q1 Q2 Q3 Q4 TotalTotal revenues $1 |
| 37 | 1 | 88 | Item 9. Changes in and Disagreements with Accountants on Accounting and Financial Disclosure | ITEM 9. CHANGES IN AND DISAGREE MENTS WITH ACCOUNTANTS ON ACCOUNTING AND FINANCIAL DISCLOSURENone.ITEM 9A.CONTROLS AND PROCEDURES Evaluation of Disclosure Contr |
| 38 | 1 | 88 | Item 9A. Controls and Procedures | ACCOUNTING AND FINANCIAL DISCLOSURENone.ITEM 9A.CONTROLS AND PROCEDURES Evaluation of Disclosure Controls and ProceduresWe maintain disclosure controls and procedures that are designed to provide reas |
| 39 | 1 | 89 | Item 9B. Other Information | ce President and Chief Financial OfficerITEM 9B.OTHER INFORMATION None.86 |
| 40 | 1 | 91 | Item 15. Exhibits and Financial Statement Schedules | PART IV ITEM 15.EXHIBITS, FINANCIAL STATEMENT SCHEDULES(a) Documents filed as part of this report are as follows:1. Financial Statements: See the Financial Statements i |
| 41 | 1 | 91 | Item 16. Form 10-K Summary | (c) Financial Statement Schedules: None.ITEM 16.FORM 10-K SUMMARY None.88 |
