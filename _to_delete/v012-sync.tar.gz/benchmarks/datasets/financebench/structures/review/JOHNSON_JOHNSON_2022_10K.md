# Review: JOHNSON_JOHNSON_2022_10K

source: 10-K schema (semi-automatic, see structures.py) · reviewed: False

## Checklist

- [ ] Heading correctness: every entry is a real heading of this filing (no references, index
      lines, table cells)
- [ ] Heading hierarchy: Items level 1; MD&A subsections, statements, auditor's report and
      Notes level 2; individual notes level 3
- [ ] Page anchor: each page is where the heading is printed (physical page, 1-based)
- [ ] Missing sections: no Item, primary statement or note is missing
- [ ] False-positive sections: nothing listed twice or out of order
- [ ] Notes hierarchy: Note 1..N consecutive, all under "Notes to Consolidated Financial
      Statements"
- [ ] Item boundaries: each Item starts where the previous one ends

## Headings

| # | level | page | title | text on the page |
|---|---|---|---|---|
| 1 | 1 | 7 | Item 1. Business | PART I Item 1. BUSINESS General Johnson & Johnson and its subsidiaries (the Company) have approximately 152,700 employees worldwide engaged in the research and develop |
| 2 | 1 | 14 | Item 1A. Risk Factors | Item 1A. RISK FACTORS An investment in the Company's common stock or debt securities involves risks and uncertainties. The Company seeks to identify, manage and |
| 3 | 1 | 22 | Item 1B. Unresolved Staff Comments | Item 1B. UNRESOLVED STAFF COMMENTS Not applicable. Item 2. PROPERTIES The Company's subsidiaries operate 89 manufacturing facilities occupying approximately 14. |
| 4 | 1 | 22 | Item 2. Properties | RESOLVED STAFF COMMENTS Not applicable. Item 2. PROPERTIES The Company's subsidiaries operate 89 manufacturing facilities occupying approximately 14.9 million square feet of floor space. The manufactu |
| 5 | 1 | 22 | Item 3. Legal Proceedings | ents included in Item 8 of this Report. Item 3. LEGAL PROCEEDINGS The information called for by this item is incorporated herein by reference to the information set forth in Note 19 "Legal Proceedings |
| 6 | 1 | 22 | Item 4. Mine Safety Disclosures | ents included in Item 8 of this Report. Item 4. MINE SAFETY DISCLOSURES Not applicable. 16 |
| 7 | 1 | 26 | Item 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities | PART II Item 5. MARKET FOR REGISTRANT'S COMMON EQUITY, RELATED STOCKHOLDER MATTERS AND ISSUER PURCHASES OF EQUITY SECURITIES As of February 10, 2023, there were 124,211 |
| 8 | 1 | 27 | Item 7. Management's Discussion and Analysis of Financial Condition and Results of Operations | Item 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF RESULTS OF OPERATIONS AND FINANCIAL CONDITION Organization and Business Segments Description of the Company and  |
| 9 | 2 | 28 | · Results of Operations | Results of Operations Analysis of Consolidated Sales For discussion on results of operations and financial condition pertaining to the fiscal years 2021 and 202 |
| 10 | 2 | 37 | · Liquidity and Capital Resources |  the Consolidated Financial Statements. Liquidity and Capital Resources Liquidity & Cash Flows Cash and cash equivalents were $14.1 billion at the end of 2022 as compared to $14.5 billion at the end o |
| 11 | 2 | 37 | · Cash Flows | idity and Capital Resources Liquidity & Cash Flows Cash and cash equivalents were $14.1 billion at the end of 2022 as compared to $14.5 billion at the end of 2021. The primary sources and uses of cash |
| 12 | 2 | 40 | · Critical Accounting Estimates | of February 21, 2023. Other Information Critical Accounting Policies and Estimates Management's discussion and analysis of results of operations and financial condition are based on the Company's cons |
| 13 | 1 | 45 | Item 7A. Quantitative and Qualitative Disclosures About Market Risk | holders of Common Stock of the Company. Item 7A. QUANTITATIVE AND QUALITATIVE DISCLOSURES ABOUT MARKET RISK The information called for by this item is incorporated herein by reference to "Item 7. Mana |
| 14 | 1 | 45 | Item 8. Financial Statements and Supplementary Data | ents included in Item 8 of this Report. Item 8. FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA Index to Audited Consolidated Financial Statements 40Consolidated Balance Sheets 41Consolidated Statements o |
| 15 | 2 | 46 | · Consolidated Balance Sheets | JOHNSON & JOHNSON AND SUBSIDIARIES CONSOLIDATED BALANCE SHEETS At January 1, 2023 and January 2, 2022 (Dollars in Millions Except Share and Per Share Amounts) (Note 1) 2022 2021 Assets Current as |
| 16 | 2 | 47 | · Consolidated Statements of Income | JOHNSON & JOHNSON AND SUBSIDIARIES CONSOLIDATED STATEMENTS OF EARNINGS (Dollars and Shares in Millions Except Per Share Amounts) (Note 1) 2022 2021 2020 Sales to customers $ 94,943 93,775 82,584  |
| 17 | 2 | 48 | · Consolidated Statements of Comprehensive Income | JOHNSON & JOHNSON AND SUBSIDIARIES CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME (Dollars in Millions) (Note 1) 2022 2021 2020 Net earnings $ 17,941 20,878 14,714 Other comprehensive income (lo |
| 18 | 2 | 49 | · Consolidated Statements of Equity | JOHNSON & JOHNSON AND SUBSIDIARIES CONSOLIDATED STATEMENTS OF EQUITY (Dollars in Millions) (Note 1) Total RetainedEarnings AccumulatedOtherComprehensiveIncome (Loss) Common StockIssued Amount Tre |
| 19 | 2 | 50 | · Consolidated Statements of Cash Flows | JOHNSON & JOHNSON AND SUBSIDIARIES CONSOLIDATED STATEMENTS OF CASH FLOWS (Dollars in Millions) (Note 1) 2022 2021 2020 Cash flows from operating activities Net earnings $ 17,941 20,878 14,714 Adj |
| 20 | 2 | 52 | · Notes to Consolidated Financial Statements | NOTES TO CONSOLIDATED FINANCIAL STATEMENTS 1. Summary of Significant Accounting Policies Principles of Consolidation The consolidated financial statements inclu |
| 21 | 3 | 52 | · · Note 1. Summary of Significant Accounting Policies | ES TO CONSOLIDATED FINANCIAL STATEMENTS 1. Summary of Significant Accounting Policies Principles of Consolidation The consolidated financial statements include the accounts of Johnson & Johnson and it |
| 22 | 3 | 57 | · · Note 2. Cash, Cash Equivalents and Current Marketable Securities | 2. Cash, Cash Equivalents and Current Marketable Securities At the end of the fiscal year 2022 and 2021, cash, cash equivalents and current marketable securitie |
| 23 | 3 | 58 | · · Note 3. Inventories | east an investment grade credit rating. 3. Inventories At the end of fiscal years 2022 and 2021, inventories were comprised of: (Dollars in Millions) 2022 2021 Raw materials and supplies $ 2,070 1,592 |
| 24 | 3 | 58 | · · Note 4. Property, Plant and Equipment | 6,508 Total inventories $ 12,483 10,387 4. Property, Plant and Equipment At the end of fiscal years 2022 and 2021, property, plant and equipment at cost and accumulated depreciation were: (Dollars in  |
| 25 | 3 | 59 | · · Note 5. Intangible Assets and Goodwill | 5. Intangible Assets and Goodwill At the end of fiscal years 2022 and 2021, the gross and net amounts of intangible assets were: (Dollars in Millions) 2022 2021 |
| 26 | 3 | 60 | · · Note 6. Fair Value Measurements | 6. Fair Value Measurements The Company uses forward foreign exchange contracts to manage its exposure to the variability of cash flows, primarily related to the |
| 27 | 3 | 66 | · · Note 7. Borrowings | 7. Borrowings The components of long-term debt are as follows: (Dollars in Millions) 2022 Effective Rate% 2021 Effective Rate% 0.250% Notes due 2022 (1B Euro 1. |
| 28 | 3 | 67 | · · Note 8. Income Taxes | 6 $1,551 1,392 1,667 1,996 2,271 19,562 8. Income Taxes The provision for taxes on income consists of: (Dollars in Millions) 2022 2021 2020 Currently payable: U.S. taxes $ 2,378 1,525 1,026 Internatio |
| 29 | 3 | 71 | · · Note 9. Employee Related Obligations | 9. Employee Related Obligations At the end of fiscal 2022 and fiscal 2021, employee related obligations recorded on the Consolidated Balance Sheets were: (Dolla |
| 30 | 3 | 71 | · · Note 10. Pensions and Other Benefit Plans | ets on the Consolidated Balance Sheets. 10. Pensions and Other Benefit Plans The Company sponsors various retirement and pension plans, including defined benefit, defined contribution and termination  |
| 31 | 3 | 76 | · · Note 11. Savings Plan | otal plan assets) at December 31, 2021. 11. Savings Plan The Company has voluntary 401(k) savings plans designed to enhance the existing retirement programs covering eligible employees. The Company ma |
| 32 | 3 | 77 | · · Note 12. Capital and Treasury Stock | 12. Capital and Treasury Stock Changes in treasury stock were: Treasury Stock (Amounts in Millions Except Treasury Stock Shares in Thousands) Shares Amount Bala |
| 33 | 3 | 77 | · · Note 13. Accumulated Other Comprehensive Income (Loss) | has been repurchased under the program. 13. Accumulated Other Comprehensive Income (Loss) Components of other comprehensive income (loss) consist of the following: (Dollars in Millions) Foreign Curren |
| 34 | 3 | 78 | · · Note 14. International Currency Translation | 14. International Currency Translation For translation of its subsidiaries operating in non-U.S. Dollar currencies, the Company has determined that the local cu |
| 35 | 3 | 78 | · · Note 15. Earnings Per Share | ears 2022, 2021 and 2020, respectively. 15. Earnings Per Share The following is a reconciliation of basic net earnings per share to diluted net earnings per share for the fiscal years ended January 1, |
| 36 | 3 | 78 | · · Note 16. Common Stock, Stock Option Plans and Stock Compensation Agreements | ge market value of the Company's stock. 16. Common Stock, Stock Option Plans and Stock Compensation AgreementsAt January 1, 2023, the Company had one stock-based compensation plan. The shares outstand |
| 37 | 3 | 81 | · · Note 17. Segments of Business | 17. Segments of Business* and Geographic Areas Sales to Customers % Change (Dollars in Millions) 2022 2021 2020 '22 vs. '21 '21 vs. '20 CONSUMER HEALTH OTC U.S. |
| 38 | 3 | 88 | · · Note 18. Acquisitions and Divestitures | 1 of $93,556 and $81,638, respectively. 18. Acquisitions and DivestituresDuring the fiscal year 2022, certain businesses were acquired for $17.7 billion in cash and $1.1 billion of liabilities assumed |
| 39 | 3 | 90 | · · Note 19. Legal Proceedings | t facility with Idorsia was terminated. 19. Legal Proceedings Johnson & Johnson and certain of its subsidiaries are involved in various lawsuits and claims regarding product liability; intellectual pr |
| 40 | 3 | 108 | · · Note 20. Restructuring | cost of past and/or future remediation. 20. Restructuring In the fiscal second quarter of 2018, the Company announced plans to implement a series of actions across its Global Supply Chain that are int |
| 41 | 2 | 109 | · Report of Independent Registered Public Accounting Firm | Report of Independent Registered Public Accounting Firm To the Board of Directors and Shareholders of Johnson & Johnson Opinions on the Financial Statements and |
| 42 | 1 | 115 | Item 11. Executive Compensation |  on the website for at least one year). Item 11. EXECUTIVE COMPENSATION The information called for by this item is incorporated herein by reference to the material under the captions "Item 1. Election |
| 43 | 1 | 115 | Item 12. Security Ownership of Certain Beneficial Owners and Management and Related Stockholder Matters | cifically incorporates it by reference. Item 12. SECURITY OWNERSHIP OF CERTAIN BENEFICIAL OWNERS AND MANAGEMENT AND RELATED STOCKHOLDER MATTERS The information called for by this item is incorporated  |
| 44 | 1 | 115 | Item 13. Certain Relationships and Related Transactions, and Director Independence | nder the 2022 Long-Term Incentive Plan. Item 13. CERTAIN RELATIONSHIPS AND RELATED TRANSACTIONS, AND DIRECTOR INDEPENDENCE The information called for by this item is incorporated herein by reference t |
| 45 | 1 | 115 | Item 14. Principal Accountant Fees and Services | n Transactions" in the Proxy Statement. Item 14. PRINCIPAL ACCOUNTANT FEES AND SERVICES The information called for by this item is incorporated herein by reference to the material under the caption "I |
| 46 | 1 | 116 | Item 15. Exhibits and Financial Statement Schedules | PART IV Item 15. EXHIBITS AND FINANCIAL STATEMENT SCHEDULES The following documents are filed as part of this report: 1. Financial Statements Consolidated Balance Sheet |
| 47 | 1 | 116 | Item 16. Form 10-K Summary | ce to the Exhibit Index in this Report. Item 16. FORM 10-K SUMMARY Registrants may voluntarily include a summary of information required by Form 10-K under this Item 16. The Company has elected not to |
