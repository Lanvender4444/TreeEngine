# Review: COCACOLA_2022_10K

source: 10-K schema (semi-automatic, see structures.py) · reviewed: False

## Checklist

- [ ] Heading correctness: every entry is a real heading of this filing (no references, index
      lines, table cells)
- [ ] Heading hierarchy: Items level 1; MD&A subsections, statements, auditor's report and
      Notes level 2; individual notes level 3
- [ ] Page anchor: each page is where the heading is printed (physical page, 1-based)
- [ ] Missing sections: no Item, primary statement or note is missing
- [ ] False-positive sections: nothing listed twice or out of order
- [ ] Notes hierarchy: Note 1..N consecutive, all under "Notes to Consolidated Financial
      Statements"
- [ ] Item boundaries: each Item starts where the previous one ends

## Headings

| # | level | page | title | text on the page |
|---|---|---|---|---|
| 1 | 1 | 4 | Item 1. Business | curities andExchange Commission. Part I ITEM 1. BUSINESS In this report, the terms "The Coca-Cola Company," "Company," "we," "us" and "our" mean The Coca-Cola Company and all entities included in our  |
| 2 | 1 | 14 | Item 1A. Risk Factors | efollowing address: http://www.sec.gov. ITEM 1A. RISK FACTORS In addition to the other information set forth in this report, you should carefully consider the following factors, which could materially |
| 3 | 1 | 27 | Item 1B. Unresolved Staff Comments | results of operations for such periods. ITEM 1B. UNRESOLVED STAFF COMMENTS Not applicable. 25 |
| 4 | 1 | 28 | Item 2. Properties | ITEM 2. PROPERTIES Our worldwide headquarters is located on a 35-acre complex in Atlanta, Georgia. The complex includes several office buildings which are used  |
| 5 | 1 | 28 | Item 3. Legal Proceedings |  and/or dispose of existing facilities. ITEM 3. LEGAL PROCEEDINGS The Company is involved in various legal proceedings, including the proceedings specifically discussed below. Managementbelieves that, |
| 6 | 1 | 31 | Item 4. Mine Safety Disclosures |  the Company were to prevail on appeal. ITEM 4. MINE SAFETY DISCLOSURES Not applicable. ITEM X. INFORMATION ABOUT OUR EXECUTIVE OFFICERS The following are the executive officers of our Company as of F |
| 7 | 1 | 33 | Item 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities | Part II ITEM 5. MARKET FOR REGISTRANT'S COMMON EQUITY, RELATED STOCKHOLDER MATTERS AND ISSUER PURCHASES OF EQUITYSECURITIES The principal United States market in which  |
| 8 | 1 | 35 | Item 7. Management's Discussion and Analysis of Financial Condition and Results of Operations |  the Prior Peer Group. ITEM 6. RESERVED ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS The following Management's Discussion and Analysis of Financial Co |
| 9 | 2 | 35 | · Results of Operations | AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS The following Management's Discussion and Analysis of Financial Condition and Results of Operations ("MD&A") is intended to help the reade |
| 10 | 2 | 38 | · Critical Accounting Estimates | s and uncertainties facing our Company. CRITICAL ACCOUNTING POLICIES AND ESTIMATES Our consolidated financial statements are prepared in accordance with accounting principles generally accepted in the |
| 11 | 2 | 58 | · Contractual Obligations | Contractual Obligations As of December 31, 2022, the Company's contractual obligations, including payments due by period, were as follows (in millions): Payment |
| 12 | 1 | 60 | Item 7A. Quantitative and Qualitative Disclosures About Market Risk |  to maintain our productive capability. ITEM 7A. QUANTITATIVE AND QUALITATIVE DISCLOSURES ABOUT MARKET RISK Our Company uses derivative financial instruments primarily to reduce our exposure to advers |
| 13 | 1 | 62 | Item 8. Financial Statements and Supplementary Data | ITEM 8. FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA Table of Contents Page Consolidated Statements of Income 61Consolidated Statements of Comprehensive Income 6 |
| 14 | 2 | 62 | · Consolidated Statements of Income | PPLEMENTARY DATA Table of Contents Page Consolidated Statements of Income 61Consolidated Statements of Comprehensive Income 62Consolidated Balance Sheets 63 Consolidated Statements of Cash Flows 64Con |
| 15 | 2 | 62 | · Consolidated Statements of Comprehensive Income | age Consolidated Statements of Income 61Consolidated Statements of Comprehensive Income 62Consolidated Balance Sheets 63 Consolidated Statements of Cash Flows 64Consolidated Statements of Shareowners' |
| 16 | 2 | 62 | · Consolidated Balance Sheets | ed Statements of Comprehensive Income 62Consolidated Balance Sheets 63 Consolidated Statements of Cash Flows 64Consolidated Statements of Shareowners' Equity 65Notes to Consolidated Financial Statemen |
| 17 | 2 | 62 | · Consolidated Statements of Cash Flows | Income 62Consolidated Balance Sheets 63 Consolidated Statements of Cash Flows 64Consolidated Statements of Shareowners' Equity 65Notes to Consolidated Financial Statements 66 Note 1 Business and Summa |
| 18 | 2 | 62 | · Consolidated Statements of Equity | Consolidated Statements of Cash Flows 64Consolidated Statements of Shareowners' Equity 65Notes to Consolidated Financial Statements 66 Note 1 Business and Summary of Significant Accounting Policies 66 |
| 19 | 2 | 68 | · Notes to Consolidated Financial Statements | THE COCA-COLA COMPANY AND SUBSIDIARIESNOTES TO CONSOLIDATED FINANCIAL STATEMENTS NOTE 1: BUSINESS AND SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES When used in these notes, the terms "The Coca-Cola Co |
| 20 | 3 | 68 | · · Note 1. Business And Summary Of Significant Accounting Policies | ES TO CONSOLIDATED FINANCIAL STATEMENTS NOTE 1: BUSINESS AND SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES When used in these notes, the terms "The Coca-Cola Company," "Company," "we," "us" and "our" mea |
| 21 | 3 | 74 | · · Note 2. Acquisitions And Divestitures | olidated balance sheet. Refer toNote 5. NOTE 2: ACQUISITIONS AND DIVESTITURES Acquisitions During 2022, our Company's acquisitions of businesses, equity method investments and nonmarketable securities |
| 22 | 3 | 76 | · · Note 3. Net Operating Revenues | 5 Liabilities held for sale $ 160 $ 157 NOTE 3: NET OPERATING REVENUES Our Company markets, manufactures and sells: • beverage concentrates, sometimes referred to as "beverage bases," and syrups, incl |
| 23 | 3 | 78 | · · Note 4. Investments | NOTE 4: INVESTMENTS We measure all equity investments that do not result in consolidation and are not accounted for under the equity method at fair value with t |
| 24 | 3 | 80 | · · Note 5. Hedging Transactions And Derivative Financial Instruments | able to satisfy our currentobligations. NOTE 5: HEDGING TRANSACTIONS AND DERIVATIVE FINANCIAL INSTRUMENTS The Company is directly and indirectly affected by changes in certain market conditions. These |
| 25 | 3 | 86 | · · Note 6. Equity Method Investments | — net — (3) (55) Total $ (13)$ (73)$ 77 NOTE 6: EQUITY METHOD INVESTMENTS Our consolidated net income includes our Company's proportionate share of the net income or loss of our equity method investee |
| 26 | 3 | 88 | · · Note 7. Intangible Assets | NOTE 7: INTANGIBLE ASSETS Indefinite-Lived Intangible Assets The following table presents the carrying values of indefinite-lived intangible assets included in  |
| 27 | 3 | 89 | · · Note 8. Accounts Payable And Accrued Expenses | 23 $ 89 2024 65 2025 57 2026 45 2027 44 NOTE 8: ACCOUNTS PAYABLE AND ACCRUED EXPENSES Accounts payable and accrued expenses consisted of the following (in millions): December 31, 2022 2021 Accounts pa |
| 28 | 3 | 89 | · · Note 9. Leases | r to Note 2 for additional information. NOTE 9: LEASES We have operating leases primarily for real estate, manufacturing and other equipment, aircraft, and vehicles. Balance sheet information related  |
| 29 | 3 | 90 | · · Note 10. Debt And Borrowing Arrangements | tal operating lease liabilities $ 1,454 NOTE 10: DEBT AND BORROWING ARRANGEMENTS Short-Term Borrowings Loans and notes payable consist primarily of commercial paper issued in the United States. As of  |
| 30 | 3 | 92 | · · Note 11. Commitments And Contingencies | NOTE 11: COMMITMENTS AND CONTINGENCIES Guarantees As of December 31, 2022, we were contingently liable for guarantees of indebtedness owed by third parties of $ |
| 31 | 3 | 94 | · · Note 12. Stock-Based Compensation Plans | cember 31, 2022 and 2021, respectively. NOTE 12: STOCK-BASED COMPENSATION PLANS Our Company grants long-term equity awards under its stock-based compensation plans to certain employees of the Company. |
| 32 | 3 | 98 | · · Note 13. Pension And Other Postretirement Benefit Plans | NOTE 13: PENSION AND OTHER POSTRETIREMENT BENEFIT PLANS Our Company sponsors a qualified pension plan covering substantially all U.S. employees as well as unfun |
| 33 | 3 | 104 | · · Note 14. Income Taxes | drawal liability, if any, at that time. NOTE 14: INCOME TAXES Income before income taxes consisted of the following (in millions): Year Ended December 31, 2022 2021 2020 United States $ 3,452 $ 3,538  |
| 34 | 3 | 108 | · · Note 15. Other Comprehensive Income |  losses and excess foreign tax credits. NOTE 15: OTHER COMPREHENSIVE INCOME AOCI attributable to shareowners of The Coca-Cola Company is separately presented in our consolidated balance sheet as a com |
| 35 | 3 | 111 | · · Note 16. Fair Value Measurements | idated net income $ 78 Refer to Note 2. NOTE 16: FAIR VALUE MEASUREMENTS U.S. GAAP defines fair value as the exchange price that would be received for an asset or paid to transfer a liability (an exit |
| 36 | 3 | 117 | · · Note 17. Significant Operating And Nonoperating Items | NOTE 17: SIGNIFICANT OPERATING AND NONOPERATING ITEMS Other Operating Charges In 2022, the Company recorded other operating charges of $1,215 million. These cha |
| 37 | 3 | 118 | · · Note 18. Restructuring | n our operating segments and Corporate. NOTE 18: RESTRUCTURING Strategic Realignment In August 2020, the Company announced strategic steps to transform our organizational structure in an effort to bet |
| 38 | 3 | 120 | · · Note 19. Operating Segments |  balance at end of year $ 4 $ — $ 2 $ 6 NOTE 19: OPERATING SEGMENTS Our organizational structure consists of the following operating segments: Europe, Middle East and Africa; Latin America; North Amer |
| 39 | 3 | 125 | · · Note 20. Net Change In Operating Assets And Liabilities | thout areadily determinable fair value. NOTE 20: NET CHANGE IN OPERATING ASSETS AND LIABILITIES Net cash provided by (used in) operating activities attributable to the net change in operating assets a |
| 40 | 2 | 128 | · Report of Independent Registered Public Accounting Firm | Report of Independent Registered Public Accounting Firm To the Shareowners and the Board of Directors of The Coca-Cola Company Opinion on the Financial Statemen |
| 41 | 1 | 132 | Item 12. Security Ownership of Certain Beneficial Owners and Management and Related Stockholder Matters | ITEM 12. SECURITY OWNERSHIP OF CERTAIN BENEFICIAL OWNERS AND MANAGEMENT AND RELATED STOCKHOLDER MATTERS The information under the subheading "Equity Compensatio |
| 42 | 1 | 132 | Item 13. Certain Relationships and Related Transactions, and Director Independence | t are incorporated herein by reference. ITEM 13. CERTAIN RELATIONSHIPS AND RELATED TRANSACTIONS, AND DIRECTOR INDEPENDENCE The information under the subheading "Director Independence and Related Perso |
| 43 | 1 | 132 | Item 14. Principal Accountant Fees and Services | nt is incorporated herein by reference. ITEM 14. PRINCIPAL ACCOUNTANT FEES AND SERVICES The information regarding Audit Fees, Audit-Related Fees, Tax Fees, All Other Fees and Audit Committee Pre-Appro |
| 44 | 1 | 132 | Item 15. Exhibits and Financial Statement Schedules | corporated herein by reference. Part IV ITEM 15. EXHIBITS AND FINANCIAL STATEMENT SCHEDULES (a) The following documents are filed as part of this report: (1) Financial Statements: Consolidated Stateme |
| 45 | 1 | 141 | Item 16. Form 10-K Summary | ts pursuant to Item 15(b) of Form 10-K. ITEM 16. FORM 10-K SUMMARY None. 139 |
