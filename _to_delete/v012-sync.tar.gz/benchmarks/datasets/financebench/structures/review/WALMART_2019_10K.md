# Review: WALMART_2019_10K

source: 10-K schema (semi-automatic, see structures.py) · reviewed: False

## Checklist

- [ ] Heading correctness: every entry is a real heading of this filing (no references, index
      lines, table cells)
- [ ] Heading hierarchy: Items level 1; MD&A subsections, statements, auditor's report and
      Notes level 2; individual notes level 3
- [ ] Page anchor: each page is where the heading is printed (physical page, 1-based)
- [ ] Missing sections: no Item, primary statement or note is missing
- [ ] False-positive sections: nothing listed twice or out of order
- [ ] Notes hierarchy: Note 1..N consecutive, all under "Notes to Consolidated Financial
      Statements"
- [ ] Item boundaries: each Item starts where the previous one ends

## Headings

| # | level | page | title | text on the page |
|---|---|---|---|---|
| 1 | 1 | 7 | Item 1. Business | ITEM 1. BUSINESS GeneralWalmart Inc. ("Walmart," the "Company" or "we") helps people around the world save money and live better – anytime and anywhere – by pro |
| 2 | 1 | 15 | Item 1A. Risk Factors | onths following the amendment or waiver.ITEM 1A.RISK FACTORS The risks described below could materially and adversely affect our business, results of operations, financial condition and liquidity. Our |
| 3 | 1 | 23 | Item 1B. Unresolved Staff Comments | foperations or cash flows in the future.ITEM 1B.UNRESOLVED STAFF COMMENTS None.23 |
| 4 | 1 | 24 | Item 2. Properties | ITEM 2. PROPERTIES United StatesThe Walmart U.S. and Sam's Club segments comprise the Company's operations in the U.S. As of January 31, 2019 , unit counts for  |
| 5 | 1 | 27 | Item 4. Mine Safety Disclosures | alleges that the wall is non-conforming.ITEM 4.MINE SAFETY DISCLOSURES Not applicable.27 |
| 6 | 1 | 28 | Item 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities | PART II ITEM 5.MARKET FOR REGISTRANT'S COMMON EQUITY, RE LATED STOCKHOLDER MATTERS AND ISSUER PURCHASES OF EQUITY SECURITIESMarket for Common StockWalmart's common stoc |
| 7 | 1 | 29 | Item 6. Selected Financial Data | een repurchased at the end of the month.ITEM 6.SELECTED FINANCIAL DATA Five-Year Financial Summary Walmart Inc. As of and for the Fiscal Years Ended January 31, (Amounts in millions, except per share  |
| 8 | 1 | 30 | Item 7. Management's Discussion and Analysis of Financial Condition and Results of Operations | ITEM 7. MANAGEMENT'S DISCUSSI ON AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONSOverviewThis discussion, which presents our results for the fiscal |
| 9 | 2 | 40 | · Contractual Obligations | Contractual Obligations The following table sets forth certain information concerning our obligations to make contractual future payments, such as debt and leas |
| 10 | 1 | 43 | Item 7A. Quantitative and Qualitative Disclosures About Market Risk | ITEM 7A. QUANTITATIVE AND QUALITATIVE DISCL OSURES ABOUT MARKET RISKMarket RiskIn addition to the risks inherent in our operations, we are exposed to certain ma |
| 11 | 1 | 45 | Item 8. Financial Statements and Supplementary Data | ITEM 8. FINANCIAL STATEMENTS AND SUPPLEMENTARY DATAConsolidated Financial Statements of Walmart Inc. For the Fiscal Year Ended January 31, 2019 Table of Content |
| 12 | 2 | 45 | · Report of Independent Registered Public Accounting Firm | January 31, 2019 Table of Contents Page Report of Independent Registered Public Accounting Firm46 Report of Independent Registered Public Accounting Firm on Internal Control over Financial Reporting47 |
| 13 | 2 | 48 | · Consolidated Statements of Income | Walmart Inc. Consolidated Statements of Income Fiscal Years Ended January 31, (Amounts in millions, except per share data) 2019 2018 2017Revenues: Net sales $510,329 $495,76 |
| 14 | 2 | 49 | · Consolidated Statements of Comprehensive Income | Walmart Inc. Consolidated Statements of Comprehensive Income Fiscal Years Ended January 31, (Amounts in millions) 2019 2018 2017Consolidated net income $7,179 $10,523 $14,29 |
| 15 | 2 | 50 | · Consolidated Balance Sheets | Walmart Inc. Consolidated Balance Sheets As of January 31, (Amounts in millions) 2019 2018ASSETS Current assets: Cash and cash equivalents $7,722 $6,756 Receivables, net 6,2 |
| 16 | 2 | 51 | · Consolidated Statements of Equity | Walmart Inc. Consolidated Statements of Shareholders' Equity Accumulated Total Capital in Other Walmart (Amounts in millions)Common Stock Excess of Retained Comprehensive Sh |
| 17 | 2 | 52 | · Consolidated Statements of Cash Flows | Walmart Inc. Consolidated Statements of Cash Flows Fiscal Years Ended January 31, (Amounts in millions) 2019 2018 2017Cash flows from operating activities: Consolidated net  |
| 18 | 2 | 53 | · Notes to Consolidated Financial Statements | Walmart Inc. Notes to Consolidated Financial StatementsNote 1. Summary of Significant Accounting PoliciesGeneralWalmart Inc. ("Walmart" or the "Company") helps people around |
| 19 | 3 | 53 | · · Note 1. Summary | tes to Consolidated Financial StatementsNote 1. Summary of Significant Accounting PoliciesGeneralWalmart Inc. ("Walmart" or the "Company") helps people around the world save money and live better – an |
| 20 | 3 | 61 | · · Note 2. Net | Note 2. Net Income Per Common Share Basic net income per common share attributable to Walmart is based on the weighted-average common shares outstanding during  |
| 21 | 3 | 61 | · · Note 3. Shareholders' | 2.28 $3.29 $4.40 Diluted 2.26 3.28 4.38 Note 3. Shareholders' EquityThe total authorized shares of $0.10 par value common stock is 11.0 billion , of which 2.9 billion and 3.0 billion were issued and o |
| 22 | 3 | 64 | · · Note 4. Accumulated | Note 4. Accumulated Other Comprehensive Loss The following table provides the changes in the composition of total accumulated other comprehensive loss for fisca |
| 23 | 3 | 64 | · · Note 5. Accrued | any's Consolidated Statements of Income.Note 5. Accrued LiabilitiesThe Company's accrued liabilities consist of the following as of January 31, 2019 and 2018 : January 31, (Amounts in millions) 2019 2 |
| 24 | 3 | 65 | · · Note 6. Short-term | Note 6. Short-term Borrowings and Long-term Debt Short-term borrowings consist of commercial paper and lines of credit. Short-term borrowings as of January 31,  |
| 25 | 3 | 68 | · · Note 7. Fair | Note 7. Fair Value Measurements Assets and liabilities recorded at fair value are measured using the fair value hierarchy, which prioritizes the inputs used in  |
| 26 | 3 | 69 | · · Note 8. Derivatives | ne year $45,396 $49,570 $33,783 $38,766 Note 8. DerivativesIn connection with various derivative agreements, including master netting arrangements, the Company held cash collateral from counterparties |
| 27 | 3 | 69 | · · Note 9. Taxes |  the next 12 months are not significant.Note 9. TaxesThe components of income before income taxes are as follows: Fiscal Years Ended January 31, (Amounts in millions)2019 2018 2017U.S.15,875 10,722 15 |
| 28 | 3 | 73 | · · Note 10. Contingencies | pany's Consolidated FinancialStatements.Note 10. ContingenciesLegal ProceedingsThe Company is involved in a number of legal proceedings. The Company has made accruals with respect to these matters, wh |
| 29 | 3 | 75 | · · Note 11. Commitments |  operations or cash flows in the future.Note 11. CommitmentsRentals (including amounts applicable to taxes, insurance, maintenance, other operating expenses and contingent rentals) under operating lea |
| 30 | 3 | 75 | · · Note 12. Retirement-Related | ch may trigger an escalation in rentals.Note 12. Retirement-Related BenefitsThe Company offers a 401(k) plan for associates in the U.S. under which eligible associates can begin contributing to the pl |
| 31 | 3 | 76 | · · Note 13. Acquisitions, | t arrangements that are not significant.Note 13. Acquisitions, Disposals and Related ItemsThe following significant transactions impact, or are expected to impact, the operations of the Company's Walm |
| 32 | 3 | 77 | · · Note 14. Restructuring | ely$0.8 billion over a five year period.Note 14. Restructuring ChargesIn fiscal 2018, the Company announced several organizational changes to position the business for more efficient growth going forw |
| 33 | 3 | 77 | · · Note 15. Segments | re subsequently paid during fiscal 2019.Note 15. Segments and Disaggregated RevenueSegmentsThe Company is engaged in the operation of retail, wholesale and other units, as well as eCommerce websites,  |
| 34 | 3 | 80 | · · Note 16. Subsequent | Note 16. Subsequent Event Dividends DeclaredThe Board of Directors approved, effective February 19, 2019 , the fiscal 2020 annual dividend of $2.12 per share, a |
| 35 | 3 | 80 | · · Note 17. Quarterly |  3, 2019December 6, 2019 January 2, 2020Note 17. Quarterly Financial Data (Unaudited) Fiscal Year Ended January 31, 2019 (Amounts in millions, except per share data) Q1 Q2 Q3 Q4 TotalTotal revenues $1 |
| 36 | 1 | 81 | Item 9. Changes in and Disagreements with Accountants on Accounting and Financial Disclosure | ITEM 9. CHANGES IN AND DISAGREE MENTS WITH ACCOUNTANTS ON ACCOUNTING AND FINANCIAL DISCLOSURENone.ITEM 9A.CONTROLS AND PROCEDURES GeneralManagement is responsib |
| 37 | 1 | 81 | Item 9A. Controls and Procedures | ACCOUNTING AND FINANCIAL DISCLOSURENone.ITEM 9A.CONTROLS AND PROCEDURES GeneralManagement is responsible for the preparation, integrity and objectivity of Walmart Inc.'s Consolidated Financial Stateme |
| 38 | 1 | 82 | Item 9B. Other Information | ce President and Chief Financial OfficerITEM 9B.OTHER INFORMATION None.80 |
| 39 | 1 | 84 | Item 15. Exhibits and Financial Statement Schedules | PART IV ITEM 15.EXHIBITS, FINANCIAL STATEMENT SCHEDULES(a) Documents filed as part of this report are as follows:1. Financial Statements: See the Financial Statements i |
| 40 | 1 | 84 | Item 16. Form 10-K Summary | (c) Financial Statement Schedules: None.ITEM 16.FORM 10-K SUMMARY None.82 |
