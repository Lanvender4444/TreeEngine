# Review: MGMRESORTS_2020_10K

source: 10-K schema (semi-automatic, see structures.py) · reviewed: False

## Checklist

- [ ] Heading correctness: every entry is a real heading of this filing (no references, index
      lines, table cells)
- [ ] Heading hierarchy: Items level 1; MD&A subsections, statements, auditor's report and
      Notes level 2; individual notes level 3
- [ ] Page anchor: each page is where the heading is printed (physical page, 1-based)
- [ ] Missing sections: no Item, primary statement or note is missing
- [ ] False-positive sections: nothing listed twice or out of order
- [ ] Notes hierarchy: Note 1..N consecutive, all under "Notes to Consolidated Financial
      Statements"
- [ ] Item boundaries: each Item starts where the previous one ends

## Headings

| # | level | page | title | text on the page |
|---|---|---|---|---|
| 1 | 1 | 3 | Item 1. Business | PART I ITEM 1.BUSINESS MGM Resorts International is referred to as the "Company," "MGM Resorts," or the "Registrant," and together with its subsidiaries may also be re |
| 2 | 1 | 16 | Item 1A. Risk Factors | ITEM 1A.RISK FACTORS You should be aware that the occurrence of any of the events described in this section and elsewhere in this report or in any other of our  |
| 3 | 1 | 33 | Item 1B. Unresolved Staff Comments | rest or an actual conflict of interest. ITEM 1B. UNRESOLVED STAFF COMMENTS None.31 |
| 4 | 1 | 34 | Item 2. Properties | ITEM 2.P ROPERTIES The location and general characteristics of our properties are provided in Part I, Item 1. Business. As detailed in the aforementioned sectio |
| 5 | 1 | 35 | Item 3. Legal Proceedings | ITEM 3.LEGAL PROCEEDINGS See discussion of legal proceedings in Note 12 – Commitments and Contingencies in the accompanying co nsolidated financial statements.  |
| 6 | 1 | 35 | Item 4. Mine Safety Disclosures | ing co nsolidated financial statements. ITEM 4.MINE SAFETY DISCLOSURES Not applicable. 33 |
| 7 | 1 | 36 | Item 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities | PART II ITEM 5.MARKET FOR REGISTRANT'S COMMON EQUITY, RELATED STOCKHOLDER MATTERS AND ISSUER PURCHASES OFEQUITY SECURITIES Common Stock Information Our common stock is  |
| 8 | 1 | 38 | Item 7. Management's Discussion and Analysis of Financial Condition and Results of Operations | ITEM 6.REMOVED AND RESERVED ITEM 7.MANAGEMENT'S DISCUSSI ON AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS This management's discussion and analysis of financial condition a |
| 9 | 1 | 59 | Item 7A. Quantitative and Qualitative Disclosures About Market Risk | ITEM 7A. QUANTITATIVE AND QUALITATIVE DISCL OSURES ABOUT MARKET RISK Market Risk In addition to the inherent risks associated with our normal operations, we are |
| 10 | 1 | 60 | Item 8. Financial Statements and Supplementary Data | ITEM 8.FINANCIAL STATEMENT S AND SUPPLEMENTARY DATA Financial Statements: Report of Independent Registered Public Accounting Firm on Internal Control Over Finan |
| 11 | 2 | 60 | · Report of Independent Registered Public Accounting Firm | UPPLEMENTARY DATA Financial Statements: Report of Independent Registered Public Accounting Firm on Internal Control Over Financial Reporting 59Report of Independent Registered Public Accounting Firm o |
| 12 | 2 | 64 | · Consolidated Balance Sheets |  RESORTS INTERNATI ONAL AND SUBSIDIARIESCONSOLIDATED BALANCE SHEETS(In thousands, except share data) December 31, 2020 2019 ASSETS Current assets Cash and cash equivalents $5,101,637 $2,329,604 Accoun |
| 13 | 2 | 65 | · Consolidated Statements of Income |  RESORTS INTERNATI ONAL AND SUBSIDIARIESCONSOLIDATED STATEMENTS OF OPERATIONS(In thousands, except per share data) Year Ended December 31, 2020 2019 2018 Revenues Casino $2,871,720 $6,517,759 $5,753,1 |
| 14 | 2 | 66 | · Consolidated Statements of Comprehensive Income |  RESORTS INTERNATI ONAL AND SUBSIDIARIESCONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME (LOSS)(In thousands) Year Ended December 31, 2020 2019 2018 Net income (loss) $(1,319,907) $2,214,380 $583,894 O |
| 15 | 2 | 67 | · Consolidated Statements of Cash Flows |  RESORTS INTERNATI ONAL AND SUBSIDIARIESCONSOLIDATED STATEMENTS OF CASH FLOWS(In thousands) Year Ended December 31, 2020 2019 2018 Cash flows from operating activities Net income (loss) $(1,319,907 )  |
| 16 | 2 | 68 | · Consolidated Statements of Equity |  RESORTS INTERNATI ONAL AND SUBSIDIARIESCONSOLIDATED STATEMENTS OF STOCKHOLDERS' EQUITYFor the Years ended December 31, 2020, 2019 and 2018(In thousands ) Total Retained Accumulated MGM Resorts Common |
| 17 | 2 | 69 | · Notes to Consolidated Financial Statements |  RESORTS INTERNATI ONAL AND SUBSIDIARIESNOTES TO CONSOLIDATED FINANCIAL STATEMENTS NOTE 1 — ORGANIZATION Organization. MGM Resorts International (together with its consolidated subsidiaries, unless ot |
| 18 | 3 | 69 | · · Note 1. Organization | ES TO CONSOLIDATED FINANCIAL STATEMENTS NOTE 1 — ORGANIZATION Organization. MGM Resorts International (together with its consolidated subsidiaries, unless otherwise indicated or unless the context req |
| 19 | 3 | 71 | · · Note 2. Basis Of Presentation And Significant Accounting Policies | during 2021 and potentially thereafter. NOTE 2 — BASIS OF PRESENTATION AND SIGNIFICANT ACCOUNTING POLICIESPrinciples of consolidation. The Company evaluates entities for which control is achieved thro |
| 20 | 3 | 77 | · · Note 3. Accounts Receivable, Net | ial impact on its financial statements. NOTE 3 — ACCOUNTS RECEIVABLE, NET Accounts receivable, net consisted of the following: December 31, 2020 2019 (In thousands) Casino $260,998 $394,163 Hotel 46,2 |
| 21 | 3 | 77 | · · Note 4. Acquisition |  (126,589 ) (94,561 ) $316,502 $612,717 NOTE 4 — ACQUISITION Empire City On January 29, 2019, the Company acquired the real property and operations associated with Empire City for total consideration  |
| 22 | 3 | 78 | · · Note 5. Property And Equipment, Net | the consolidated results of operations. NOTE 5 — PROPERTY AND EQUIPMENT, NET Property and equipment, net consisted of the following: December 31, 2020 2019 (In thousands) Land $4,081,029 $5,348,223 Bu |
| 23 | 3 | 79 | · · Note 6. Investments In And Advances To Unconsolidated Affiliates | NOTE 6 — INVESTMENTS IN AND ADVANCES TO UNCONSOLIDATED AFFILIATES Investments in and advances to unconsolidated affiliates consisted of the following: December  |
| 24 | 3 | 81 | · · Note 7. Goodwill And Other Intangible Assets | NOTE 7 — GOODWILL AND OTHER INTANGIBLE ASSETSGoodwill and other intangible assets consisted of the following: December 31, 2020 2019 (In thousands) Goodwill $2, |
| 25 | 3 | 82 | · · Note 8. Other Accrued Liabilities | 174,900 Thereafter 2,048,070 $2,966,412 NOTE 8 — OTHER ACCRUED LIABILITIES Other accrued liabilities consisted of the following: December 31, 2020 2019 (In thousands) Contract and contract-related lia |
| 26 | 3 | 83 | · · Note 9. Long-Term Debt | NOTE 9 — LONG-TERM DEBT Long-term debt consisted of the following: December 31, 2020 2019 (In thousands) Senior credit facility $— $— Operating Partnership seni |
| 27 | 3 | 86 | · · Note 10. Income Taxes | y's senior notes and credit facilities. NOTE 10 — INCOME TAXES The Company recognizes deferred income tax assets, net of applicable reserves, related to net operating losses, tax credit carryforwards  |
| 28 | 3 | 90 | · · Note 11. Leases | ew Jersey examinations described above. NOTE 11 – LEASES The Company leases the land underlying certain of its properties, real estate, and various equipment under operating and, to a lesser extent, f |
| 29 | 3 | 93 | · · Note 12. Commitments And Contingencies | f lease liabilities$ 8,390,117 $134,287 NOTE 12 – COMMITMENTS AND CONTINGENCIES October 1 litigation. The Company and/or certain of its subsidiaries were named as defendants in a number of lawsuits re |
| 30 | 3 | 95 | · · Note 13. Stockholders' Equity | NOTE 13 — STOCKHOLDERS' EQUITY Accumulated Other Comprehensive Loss Changes in accumulated other comprehensive loss attributable to MGM Resorts International ar |
| 31 | 3 | 98 | · · Note 14. Stock-Based Compensation Mgm | llion. Repurchased shares were retired. NOTE 14 — STOCK-BASED COMPENSATION MGM Resorts 2005 Omnibus Incentive Plan. The Company's omnibus incentive plan, as amended (the "Omnibus Plan"), allows it to  |
| 32 | 3 | 98 | · · Note 15. Employee Benefit Plans |  of tax benefit $84,233 $68,599 $55,268 NOTE 15 — EMPLOYEE BENEFIT PLANS Multiemployer benefit plans. The Company currently participates in multiemployer pension plans in which the risks of participat |
| 33 | 3 | 99 | · · Note 16. Property Transactions, Net | 31, 2020, 2019, and 2018, respectively. NOTE 16 — PROPERTY TRANSACTIONS, NET Property transactions, net consisted of the following: Year Ended December 31, 2020 2019 2018 (In thousands) Loss related t |
| 34 | 3 | 100 | · · Note 17. Segment Information | o Park MGM and NoMad Las Vegas in 2018. NOTE 17 — SEGMENT INFORMATION The Company's management views each of its casino resorts as an operating segment. Operating segments are aggregated based on thei |
| 35 | 3 | 102 | · · Note 18. Related Party Transactions | 804 $28,653,811 $28,589,504 $26,495,743 NOTE 18 — RELATED PARTY TRANSACTIONS CityCenter Management agreements. The Company and CityCenter have entered into agreements whereby the Company is responsibl |
| 36 | 1 | 106 | Item 9. Changes in and Disagreements with Accountants on Accounting and Financial Disclosure | ITEM 9.CHANGES IN AND DISAGREE MENTS WITH ACCOUNTANTS ON ACCOUNTING AND FINANCIAL DISCLOSURE None. ITEM 9A.CONTROL S AND PROCEDURES Disclosure Controls and Proc |
| 37 | 1 | 106 | Item 9A. Controls and Procedures | COUNTING AND FINANCIAL DISCLOSURE None. ITEM 9A.CONTROL S AND PROCEDURES Disclosure Controls and Procedures Our Chief Executive Officer (principal executive officer) and Chief Financial Officer (princ |
| 38 | 1 | 106 | Item 9B. Other Information | ver financial reporting appears herein. ITEM 9B. OTHER INFORMATION None.104 |
| 39 | 1 | 108 | Item 15. Exhibits and Financial Statement Schedules | PART IV ITEM 15.EXHIBITS, FINANCIAL STATEMENT SCHEDULES(a)(1).Financial Statements. The following consolidated financial statements of the Company are filed as part of  |
| 40 | 1 | 116 | Item 16. Form 10-K Summary | h by specific reference in such filing. ITEM 16.FORM 10-K SUMMARY None.114 |
