# Review: LOCKHEEDMARTIN_2022_10K

source: 10-K schema (semi-automatic, see structures.py) · reviewed: False

## Checklist

- [ ] Heading correctness: every entry is a real heading of this filing (no references, index
      lines, table cells)
- [ ] Heading hierarchy: Items level 1; MD&A subsections, statements, auditor's report and
      Notes level 2; individual notes level 3
- [ ] Page anchor: each page is where the heading is printed (physical page, 1-based)
- [ ] Missing sections: no Item, primary statement or note is missing
- [ ] False-positive sections: nothing listed twice or out of order
- [ ] Notes hierarchy: Note 1..N consecutive, all under "Notes to Consolidated Financial
      Statements"
- [ ] Item boundaries: each Item starts where the previous one ends

## Headings

| # | level | page | title | text on the page |
|---|---|---|---|---|
| 1 | 1 | 3 | Item 1. Business | PART I ITEM 1. Business General We are a global security and aerospace company principally engaged in the research, design, development, manufacture, integration and s |
| 2 | 1 | 10 | Item 1A. Risk Factors | rovided by the federal securities laws. ITEM 1A. Risk Factors An investment in our common stock or debt securities involves risks and uncertainties. We seek to identify, manage and mitigate risks to o |
| 3 | 1 | 23 | Item 1B. Unresolved Staff Comments | apital requirements and applicable law. ITEM 1B. Unresolved Staff Comments None. ITEM 2. Properties At December 31, 2022 , we owned or leased building space (including offices, manufacturing plants, w |
| 4 | 1 | 23 | Item 2. Properties | TEM 1B. Unresolved Staff Comments None. ITEM 2. Properties At December 31, 2022 , we owned or leased building space (including offices, manufacturing plants, warehouses, service centers, laboratories  |
| 5 | 1 | 24 | Item 3. Legal Proceedings | te to meet the needs of our operations. ITEM 3. Legal Proceedings We are a party to litigation and other proceedings that arise in the ordinary course of our business, including matters arising under  |
| 6 | 1 | 24 | Item 4. Mine Safety Disclosures | s to Consolidated Financial Statements. ITEM 4. Mine Safety Disclosures Not applicable. ITEM 4(a). Information about our Executive Officers Our executive officers as of January 26, 2023 are listed bel |
| 7 | 1 | 26 | Item 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities | PART II ITEM 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities At January 20, 2023, we had 23,358 holders  |
| 8 | 1 | 28 | Item 6. Selected Financial Data | ITEM 6. Selected Financial Data (In millions, except per share data) 2022 2021 2020 2019 2018 Operating results Net sales $ 65,984 $ 67,044 $ 65,398 $ 59,812 $  |
| 9 | 1 | 30 | Item 7. Management's Discussion and Analysis of Financial Condition and Results of Operations | ITEM 7. Management's Discussion and Analysis of Financial Condition and Results of Operations The following Management's Discussion and Analysis of Financial Co |
| 10 | 2 | 34 | · Results of Operations | ch of our business segments, see below. Consolidated Results of Operations Our operating cycle is primarily long term and involves many types of contracts for the design, development and manufacture o |
| 11 | 2 | 50 | · Critical Accounting Estimates | arty guarantees or novation agreements. Critical Accounting Policies Contract Accounting / Sales Recognition The majority of our net sales are generated from long-term contracts with the U.S. Governme |
| 12 | 2 | 53 | · Overview | it Agency. Postretirement Benefit Plans Overview Many of our employees and retirees participate in qualified and nonqualified defined benefit pension plans, retiree medical and life insurance plans an |
| 13 | 1 | 58 | Item 7A. Quantitative and Qualitative Disclosures About Market Risk | ITEM 7A. Quantitative and Qualitative Disclosures About Market Risk We maintain active relationships with a broad and diverse group of U.S. and international fi |
| 14 | 1 | 60 | Item 8. Financial Statements and Supplementary Data | ITEM 8. Financial Statements and Supplementary Data Report of Independent Registered Public Accounting Firm on the Audited Consolidated Financial Statements Boa |
| 15 | 2 | 60 | · Report of Independent Registered Public Accounting Firm | ncial Statements and Supplementary Data Report of Independent Registered Public Accounting Firm on the Audited Consolidated Financial Statements Board of Directors and Stockholders Lockheed Martin Cor |
| 16 | 2 | 63 | · Consolidated Statements of Income | Lockheed Martin Corporation Consolidated Statements of Earnings (in millions, except per share data) Years Ended December 31, 2022 2021 2020 Net sales Products $ 55,466 $ 56,435 $ 54,928 S |
| 17 | 2 | 64 | · Consolidated Statements of Comprehensive Income | Lockheed Martin Corporation Consolidated Statements of Comprehensive Income (in millions) Years Ended December 31, 2022 2021 2020 Net earnings $ 5,732 $ 6,315 $ 6,833 Other comprehensive i |
| 18 | 2 | 65 | · Consolidated Balance Sheets | Lockheed Martin Corporation Consolidated Balance Sheets (in millions, except par value) December 31, 2022 2021 Assets Current assets Cash and cash equivalents $ 2,547 $ 3,604 Receivables,  |
| 19 | 2 | 66 | · Consolidated Statements of Cash Flows | Lockheed Martin Corporation Consolidated Statements of Cash Flows (in millions) Years Ended December 31, 2022 2021 2020 Operating activities Net earnings $ 5,732 $ 6,315 $ 6,833 Adjustment |
| 20 | 2 | 67 | · Consolidated Statements of Equity | Lockheed Martin Corporation Consolidated Statements of Equity (in millions, except per share data) Common Stock Additional Paid-In Capital Retained Earnings Accumulated Other Comprehensive |
| 21 | 2 | 68 | · Notes to Consolidated Financial Statements | Lockheed Martin Corporation Notes to Consolidated Financial Statements Note 1 – Organization and Significant Accounting Policies Organization – We are a global security and aerospace compa |
| 22 | 3 | 68 | · · Note 1. Organization and Significant Accounting Policies | es to Consolidated Financial Statements Note 1 – Organization and Significant Accounting Policies Organization – We are a global security and aerospace company principally engaged in the research, des |
| 23 | 3 | 76 | · · Note 2. Earnings Per Share | are immediately recognized in earnings. Note 2 – Earnings Per Share The weighted average number of shares outstanding used to compute earnings per common share were as follows (in millions): 2022 2021 |
| 24 | 3 | 76 | · · Note 3. Information on Business Segments | pared to 2021 due to share repurchases. Note 3 – Information on Business Segments Overview We operate in four business segments: Aeronautics, MFC, RMS and Space. We organize our business segments base |
| 25 | 3 | 81 | · · Note 4. Receivables, net, Contract Assets and Contract Liabilities | plans and other marketable investments. Note 4 – Receivables, net, Contract Assets and Contract Liabilities Receivables, net, contract assets and contract liabilities were as follows (in millions): 20 |
| 26 | 3 | 81 | · · Note 5. Inventories | lities at December 31, 2019 as revenue. Note 5 – Inventories Inventories consisted of the following (in millions): 2022 2021 Materials, spares and supplies $ 599 $ 624 Work-in-process 2,297 2,163 Fini |
| 27 | 3 | 82 | · · Note 6. Property, Plant and Equipment, net | act costs were included in inventories. Note 6 – Property, Plant and Equipment, net Property, plant and equipment, net consisted of the following (in millions): 2022 2021 Land $ 147 $ 144 Buildings 8, |
| 28 | 3 | 82 | · · Note 7. Goodwill and Acquired Intangibles | llion in 2021 and $853 million in 2020. Note 7 – Goodwill and Acquired Intangibles Changes in the carrying amount of goodwill by business segment were as follows (in millions): Aeronautics MFC RMS Spa |
| 29 | 3 | 83 | · · Note 8. Leases | Note 8 – Leases We generally enter into operating lease agreements for facilities, land and equipment. Our ROU operating lease assets were $1.1 billion at Decem |
| 30 | 3 | 83 | · · Note 9. Income Taxes | ess: imputed interest 125 Total $ 1,217 Note 9 – Income Taxes Income Tax Provisions Federal and foreign income tax expense for continuing operations consisted of the following (in millions): 2022 2021 |
| 31 | 3 | 86 | · · Note 10. Debt | Note 10 – Debt Our total debt consisted of the following (in millions): 2022 2021 Notes 3.10% due 2023 $ — $ 500 2.90% due 2025 — 750 4.95% due 2025 500 — 3.55% |
| 32 | 3 | 87 | · · Note 11. Postretirement Benefit Plans | ended December 31, 2022, 2021 and 2020. Note 11 – Postretirement Benefit Plans Plan Descriptions Many of our employees and retirees participate in various postretirement benefit plans including define |
| 33 | 3 | 95 | · · Note 12. Stockholders' Equity | on stock at December 31, 2022 and 2021. Note 12 – Stockholders' Equity At December 31, 2022 and 2021, our authorized capital was composed of 1.5 billion shares of common stock and 50 million shares of |
| 34 | 3 | 97 | · · Note 13. Stock-Based Compensation | Note 13 – Stock-Based Compensation Stock-Based Compensation Plans Under plans approved by our stockholders, we are authorized to grant key employees stock-based |
| 35 | 3 | 97 | · · Note 14. Legal Proceedings, Commitments and Contingencies | xpense ratably over the vesting period. Note 14 – Legal Proceedings, Commitments and Contingencies We are a party to litigation and other proceedings that arise in the ordinary course of our business, |
| 36 | 3 | 100 | · · Note 15. Fair Value Measurements | arty guarantees or novation agreements. Note 15 – Fair Value Measurements Assets and liabilities measured and recorded at fair value on a recurring basis consisted of the following (in millions): Dece |
| 37 | 3 | 102 | · · Note 16. Severance and Other Charges | Note 16 – Severance and Other Charges During the fourth quarter of 2022, we recorded severance and other charges totaling $100 million ($79 million, or $0.31 pe |
| 38 | 1 | 103 | Item 9. Changes in and Disagreements with Accountants on Accounting and Financial Disclosure | ITEM 9. Changes in and Disagreements with Accountants on Accounting and Financial Disclosure None. ITEM 9A. Controls and Procedures Evaluation of Disclosure Con |
| 39 | 1 | 103 | Item 9A. Controls and Procedures | counting and Financial Disclosure None. ITEM 9A. Controls and Procedures Evaluation of Disclosure Controls and Procedures We performed an evaluation of the effectiveness of our disclosure controls and |
| 40 | 1 | 105 | Item 9B. Other Information | ITEM 9B. Other Information None. ITEM 9C. Disclosure Regarding Foreign Jurisdictions that Prevent Inspections Not applicable. PART III ITEM 10. Directors, Execu |
| 41 | 1 | 105 | Item 9C. Disclosure Regarding Foreign Jurisdictions that Prevent Inspections | ITEM 9B. Other Information None. ITEM 9C. Disclosure Regarding Foreign Jurisdictions that Prevent Inspections Not applicable. PART III ITEM 10. Directors, Executive Officers and Corporate Gover |
| 42 | 1 | 105 | Item 10. Directors, Executive Officers and Corporate Governance | nt Inspections Not applicable. PART III ITEM 10. Directors, Executive Officers and Corporate Governance The information concerning directors required by Item 401 of Regulation S-K is included under th |
| 43 | 1 | 105 | Item 11. Executive Compensation | e as permitted by applicable SEC rules. ITEM 11. Executive Compensation The information required by Item 402 of Regulation S-K is included in the text and tables under the captions "Executive Compensa |
| 44 | 1 | 106 | Item 12. Security Ownership of Certain Beneficial Owners and Management and Related Stockholder Matters | ITEM 12. Security Ownership of Certain Beneficial Owners and Management and Related Stockholder Matters The information required by Item 12 related to the secur |
| 45 | 1 | 106 | Item 13. Certain Relationships and Related Transactions, and Director Independence | e numerator) of a dilution calculation. ITEM 13. Certain Relationships and Related Transactions, and Director Independence The information required by Item 404 and 407(a) of Regulation S-K is included |
| 46 | 1 | 106 | Item 14. Principal Accountant Fees and Services | porated by reference in this Form 10-K. ITEM 14. Principal Accounting Fees and Services The information required by this Item 14 is included under the caption " Proposal 4 - Ratification of Appointmen |
| 47 | 1 | 107 | Item 15. Exhibits and Financial Statement Schedules | PART IV ITEM 15. Exhibits and Financial Statement Schedules List of financial statements filed as part of this Form 10-K The following financial statements of Lockheed  |
| 48 | 1 | 110 | Item 16. Form 10-K Summary |  or compensatory plans or arrangements. ITEM 16. Form 10-K Summary None. Table of Contents 110 |
