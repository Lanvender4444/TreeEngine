# Review: AMERICANWATERWORKS_2021_10K

source: 10-K schema (semi-automatic, see structures.py) · reviewed: False

## Checklist

- [ ] Heading correctness: every entry is a real heading of this filing (no references, index
      lines, table cells)
- [ ] Heading hierarchy: Items level 1; MD&A subsections, statements, auditor's report and
      Notes level 2; individual notes level 3
- [ ] Page anchor: each page is where the heading is printed (physical page, 1-based)
- [ ] Missing sections: no Item, primary statement or note is missing
- [ ] False-positive sections: nothing listed twice or out of order
- [ ] Notes hierarchy: Note 1..N consecutive, all under "Notes to Consolidated Financial
      Statements"
- [ ] Item boundaries: each Item starts where the previous one ends

## Headings

| # | level | page | title | text on the page |
|---|---|---|---|---|
| 1 | 1 | 6 | Item 1. Business | Table of Contents PART I ITEM 1. BUSINESSThe CompanyWith a history dating back to 1886, American Water is the largest and most geographically diverse, publicly-traded water and wastewat |
| 2 | 1 | 28 | Item 1A. Risk Factors | Table of Contents ITEM 1A. RISK FACTORSWe operate in a market and regulatory environment that involves significant risks, many of which are beyond our control. In addition to the |
| 3 | 1 | 29 | Item 3. Legal Proceedings | ber 31, 2021 (the "2021 Deadline"). See Item 3—Legal Proceedings—Alternative Water Supply in Lieu of Carmel River Diversions, which includesadditional information regarding this matter. We are also re |
| 4 | 1 | 50 | Item 4. Mine Safety Disclosures | n, results of operations and cash flows.ITEM 4. MINE SAFETY DISCLOSURESNot applicable.48 |
| 5 | 1 | 51 | Item 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities | Table of ContentsPART II ITEM 5. MARKET FOR REGISTRANT'S COMMON EQUITY, RELATED STOCKHOLDER MATTERS AND ISSUER PURCHASES OF EQUITY SECURITIESSince April 23, 2008, the Company's common s |
| 6 | 1 | 52 | Item 7. Management's Discussion and Analysis of Financial Condition and Results of Operations | Table of Contents ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONSThe following discussion should be read together with the Consolida |
| 7 | 1 | 80 | Item 7A. Quantitative and Qualitative Disclosures About Market Risk | cription of recent accounting standards.ITEM 7A. QUANTITATIVE AND QUALITATIVE DISCLOSURES ABOUT MARKET RISKThe Company is exposed to market risk associated with changes in commodity prices, equity pri |
| 8 | 1 | 81 | Item 8. Financial Statements and Supplementary Data | Table of Contents ITEM 8. FINANCIAL STATEMENTS AND SUPPLEMENTARY DATAINDEX TO CONSOLIDATED F INANCIAL STATEMENTS Page Audited Consolidated Financial Statements Report of Independ |
| 9 | 2 | 81 | · Consolidated Balance Sheets | ublic Accounting Firm (PCAOB I D 238)80 Consolidated Balance Sheets as of December 31, 2021 and 202082 Consolidated Statements of Operations for the years ended December 31, 2021 , 2020 and 201984 Con |
| 10 | 2 | 82 | · Report of Independent Registered Public Accounting Firm | Table of Contents Report of Independent Registered Public Accounting Firm To the Board of Directors and Shareholders ofAmerican Water Works Company, Inc.Opinions on the Financial |
| 11 | 2 | 86 | · Consolidated Statements of Income | s Company, Inc. and Subsidiary CompaniesConsolidated Statements of Operations(In millions, except per share data) For the Years Ended December 31, 2021 2020 2019 Operating revenues$ 3,930 $3,777 $3,61 |
| 12 | 2 | 87 | · Consolidated Statements of Comprehensive Income | s Company, Inc. and Subsidiary CompaniesConsolidated Statements of Comprehensive Income(In millions) For the Years Ended December 31, 2021 2020 2019 Net income attributable to common shareholders$ 1,2 |
| 13 | 2 | 88 | · Consolidated Statements of Cash Flows | s Company, Inc. and Subsidiary CompaniesConsolidated Statements of Cash Flows(In millions) For the Years Ended December 31, 2021 2020 2019 CASH FLOWS FROM OPERATING ACTIVITIES Net income$ 1,263 $709 $ |
| 14 | 2 | 89 | · Consolidated Statements of Equity | s Company, Inc. and Subsidiary CompaniesConsolidated Statements of Changes in Shareholders' Equity(In millions, except per share data)Common Stock Retained Earnings(Accumulated Deficit)Accumulated Oth |
| 15 | 2 | 90 | · Notes to Consolidated Financial Statements | s Company, Inc. and Subsidiary CompaniesNotes to Consolidated Financial Statements(Unless otherwise noted, in millions, except per share data)Note 1: Organization and OperationAmerican Water Works Com |
| 16 | 3 | 90 | · · Note 1. Organization and Operation | ted, in millions, except per share data)Note 1: Organization and OperationAmerican Water Works Company, Inc. (the "Company" or "American Water") is a holding company for regulated and market-based sub |
| 17 | 3 | 90 | · · Note 2. Significant Accounting Policies |  home services to residential customers.Note 2: Significant Accounting PoliciesRegulationThe Company's regulated utilities are subject to regulation by multiple state utility commissions or other enti |
| 18 | 3 | 97 | · · Note 3. Impact of the COVID-19 Pandemic | Table of Contents Note 3: Impact of the COVID-19 PandemicAmerican Water continues to monitor the COVID-19 pandemic and has experienced financial impacts since the start of the pa |
| 19 | 3 | 98 | · · Note 4. Regulatory Matters | Table of Contents Note 4: Regulatory MattersGeneral Rate CasesPresented in the table below are annualized incremental revenues, excluding reductions for the amortization of the e |
| 20 | 3 | 103 | · · Note 5. Revenue Recognition | Table of Contents Note 5: Revenue RecognitionDisaggregated RevenuesPresented in the table below are operating revenues disaggregated for the year ended December 31, 2021:Revenues |
| 21 | 3 | 106 | · · Note 6. Acquisitions and Divestitures | nized when the maintenance is performed.Note 6: Acquisitions and DivestituresRegulated BusinessesAcquisitionsDuring 2021, the Company closed on 23 acquisitions of various regulated water and wastewate |
| 22 | 3 | 108 | · · Note 7. Property, Plant and Equipment | Table of Contents Note 7: Property, Plant and EquipmentPresented in the table below are the major classes of property, plant and equipment by category as of December 31:2021 2020 |
| 23 | 3 | 109 | · · Note 8. Allowance for Uncollectible Accounts | Table of Contents Note 8: Allowance for Uncollectible AccountsPresented in the table below are the changes in the allowances for uncollectible accounts for the years ended Decemb |
| 24 | 3 | 109 | · · Note 9. Goodwill and Other Intangible Assets | Divestitures for additional information.Note 9: Goodwill and Other Intangible AssetsGoodwillPresented in the table below are the changes in the carrying value of goodwill for the years ended December  |
| 25 | 3 | 110 | · · Note 10. Shareholders' Equity | y, for the year ended December 31, 2021.Note 10: Shareholders' EquityCommon StockUnder the Company's dividend reinvestment and direct stock purchase plan (the "DRIP"), shareholders may reinvest cash c |
| 26 | 3 | 111 | · · Note 11. Stock Based Compensation | pecific financingor refinancing of debt.Note 11: Stock Based CompensationThe Company has granted stock options, stock units and dividend equivalents to non-employee directors, officers and other key e |
| 27 | 3 | 114 | · · Note 12. Long-Term Debt | nd shares, respectively, under the ESPP.Note 12: Long-Term DebtThe Company obtains long-term debt through AWCC primarily to fund capital expenditures of the Regulated Businesses and to lend funds to p |
| 28 | 3 | 116 | · · Note 13. Short-Term Debt |  years ended December 31, 2021 and 2020.Note 13: Short-Term DebtLiquidity needs for capital investment, working capital and other financial commitments are generally funded through cash flows from ope |
| 29 | 3 | 118 | · · Note 14. General Taxes | Note 14: General Taxes Presented in the table below is the components of general tax expense for the years ended December 31: 2021 2020 2019 Property and capita |
| 30 | 3 | 118 | · · Note 15. Income Taxes | 1 11 Total general taxes$ 321 $303 $280 Note 15: Income TaxesPresented in the table below is the components of income tax expense for the years ended December 31: 2021 2020 2019 Current income taxes:  |
| 31 | 3 | 120 | · · Note 16. Employee Benefits | (9) Balance as of December 31, 2021$ 10 Note 16: Employee BenefitsPension and Other Postretirement BenefitsThe Company maintains noncontributory defined benefit pension plans covering eligible employe |
| 32 | 3 | 129 | · · Note 17. Commitments and Contingencies | funds at the direction of the employees.Note 17: Commitments and ContingenciesCommitments have been made in connection with certain construction programs. The estimated capital expenditures required u |
| 33 | 3 | 132 | · · Note 18. Earnings per Common Share |  with the 2009 Order and the 2016 Order.Note 18: Earnings per Common SharePresented in the table below is a reconciliation of the numerator and denominator for the basic and diluted earnings per share |
| 34 | 3 | 133 | · · Note 19. Fair Value of Financial Information | ilutive under the treasury stock method.Note 19: Fair Value of Financial InformationThe following methods and assumptions were used by the Company in estimating its fair value disclosures for financia |
| 35 | 3 | 135 | · · Note 20. Leases | ipt of the $75 million, a Level 3 input.Note 20: LeasesThe Company has operating and finance leases involving real property, including facilities, utility assets, vehicles, and equipment. Certain oper |
| 36 | 3 | 136 | · · Note 21. Segment Information | Table of Contents Note 21: Segment InformationThe Company's operating segments are comprised of the revenue-generating components of its businesses for which separate financial i |
| 37 | 3 | 137 | · · Note 22. Unaudited Quarterly Data | r capital expenditures1,627 13 14 1,654 Note 22: Unaudited Quarterly DataPresented in the tables below are supplemental, unaudited, consolidated, quarterly financial data for each of the four quarters |
| 38 | 1 | 139 | Item 9. Changes in and Disagreements with Accountants on Accounting and Financial Disclosure | Table of Contents ITEM 9. CHANGES IN AND DISAGREEMENTS WITH ACCOUNTANTS ON ACCOUNTING AND FINANCIAL DISCLOSURENone.ITEM 9A. CONTROLS AND PROCEDURESDisclosure Controls and Procedu |
| 39 | 1 | 139 | Item 9A. Controls and Procedures | ACCOUNTING AND FINANCIAL DISCLOSURENone.ITEM 9A. CONTROLS AND PROCEDURESDisclosure Controls and ProceduresThe Company, under the supervision and with the participation of its management, including the |
| 40 | 1 | 139 | Item 9B. Other Information | ternal control over financial reporting.ITEM 9B. OTHER INFORMATIONNone.137 |
| 41 | 1 | 140 | Item 9C. Disclosure Regarding Foreign Jurisdictions that Prevent Inspections | Table of Contents ITEM 9C. DISCLOSURE REGARDING FOREIGN JURISDICTIONS THAT PREVENT INSPECTIONSNot applicable.138 |
