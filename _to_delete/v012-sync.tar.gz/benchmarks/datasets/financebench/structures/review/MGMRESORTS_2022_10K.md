# Review: MGMRESORTS_2022_10K

source: 10-K schema (semi-automatic, see structures.py) · reviewed: False

## Checklist

- [ ] Heading correctness: every entry is a real heading of this filing (no references, index
      lines, table cells)
- [ ] Heading hierarchy: Items level 1; MD&A subsections, statements, auditor's report and
      Notes level 2; individual notes level 3
- [ ] Page anchor: each page is where the heading is printed (physical page, 1-based)
- [ ] Missing sections: no Item, primary statement or note is missing
- [ ] False-positive sections: nothing listed twice or out of order
- [ ] Notes hierarchy: Note 1..N consecutive, all under "Notes to Consolidated Financial
      Statements"
- [ ] Item boundaries: each Item starts where the previous one ends

## Headings

| # | level | page | title | text on the page |
|---|---|---|---|---|
| 1 | 1 | 3 | Item 1. Business | PART I ITEM 1. BUSINESS MGM Resorts International is referred to as the "Company," "MGM Resorts," or the "Registrant," and together with its subsidiaries may also be r |
| 2 | 1 | 15 | Item 1A. Risk Factors | ITEM 1A. RISK FACTORS You should be aware that the occurrence of any of the events described in this section and elsewhere in this report or in any other of our |
| 3 | 1 | 29 | Item 1B. Unresolved Staff Comments | rest or an actual conflict of interest. ITEM 1B. UNRESOLVED STAFF COMMENTS None. 27 |
| 4 | 1 | 30 | Item 2. Properties | ITEM 2. PROPERTIES We have provided certain information below about our resorts as of December 31, 2022. Name and Location Number ofGuestrooms and Suites Approx |
| 5 | 1 | 31 | Item 3. Legal Proceedings | ITEM 3. LEGAL PROCEEDINGS See discussion of legal proceedings in Note 12 – Commitments and Contingencies in the accompanying consolidated financial statements.  |
| 6 | 1 | 31 | Item 4. Mine Safety Disclosures | ying consolidated financial statements. ITEM 4. MINE SAFETY DISCLOSURES Not applicable. 29 |
| 7 | 1 | 32 | Item 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities | PART II ITEM 5. MARKET FOR REGISTRANT'S COMMON EQUITY, RELATED STOCKHOLDER MATTERS AND ISSUER PURCHASES OF EQUITY SECURITIES Common Stock Information Our common stock i |
| 8 | 1 | 34 | Item 7. Management's Discussion and Analysis of Financial Condition and Results of Operations | ITEM 6. RESERVED ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS This management's discussion and analysis of financial condition a |
| 9 | 2 | 34 | · Results of Operations | AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS This management's discussion and analysis of financial condition and results of operations includes discussion as of and for the year ende |
| 10 | 2 | 43 | · Non-GAAP Financial Measures | ivided by related segment net revenues. Non-GAAP Measures "Same-Store Adjusted Property EBITDAR" is Adjusted Property EBITDAR further adjusted to exclude the Adjusted Property EBITDAR of acquiredopera |
| 11 | 2 | 46 | · Liquidity and Capital Resources |  to MGM Resorts International 1,668,214 Liquidity and Capital Resources Cash Flows – Summary Our cash flows consisted of the following: Year Ended December 31, 2022 2021 2020 (In thousands) Net cash p |
| 12 | 2 | 46 | · Cash Flows | 668,214 Liquidity and Capital Resources Cash Flows – Summary Our cash flows consisted of the following: Year Ended December 31, 2022 2021 2020 (In thousands) Net cash provided by (used in) operating a |
| 13 | 2 | 49 | · Critical Accounting Estimates | ebt agreements as of December 31, 2022. Critical Accounting Policies and Estimates Management's discussion and analysis of our results of operations and liquidity and capital resources are based on ou |
| 14 | 1 | 53 | Item 7A. Quantitative and Qualitative Disclosures About Market Risk | ITEM 7A. QUANTITATIVE AND QUALITATIVE DISCLOSURES ABOUT MARKET RISK Market Risk In addition to the inherent risks associated with our normal operations, we are  |
| 15 | 1 | 54 | Item 8. Financial Statements and Supplementary Data | ITEM 8. FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA Financial Statements: Reports of Independent Registered Public Accounting Firm (PCAOB ID: 34) 53 Consolidate |
| 16 | 2 | 54 | · Consolidated Balance Sheets | ublic Accounting Firm (PCAOB ID: 34) 53 Consolidated Balance Sheets — December 31, 2022 and 2021 57 Years Ended December 31, 2022, 2021 and 2020 Consolidated Statements of Operations 58 Consolidated S |
| 17 | 2 | 55 | · Report of Independent Registered Public Accounting Firm | REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM To the Stockholders and the Board of Directors of MGM Resorts International Opinion on Internal Control  |
| 18 | 2 | 60 | · Consolidated Statements of Income |  RESORTS INTERNATIONAL AND SUBSIDIARIES CONSOLIDATED STATEMENTS OF OPERATIONS(In thousands, except per share data) Year Ended December 31, 2022 2021 2020 Revenues Casino $ 5,734,173 $ 5,362,912 $ 2,87 |
| 19 | 2 | 61 | · Consolidated Statements of Comprehensive Income | M RESORTS INTERNATIONAL AND SUBSIDIARIESCONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME (LOSS) (In thousands) Year Ended December 31, 2022 2021 2020 Net income (loss) $ 206,731 $ 1,208,389 $ (1,319,90 |
| 20 | 2 | 62 | · Consolidated Statements of Cash Flows | M RESORTS INTERNATIONAL AND SUBSIDIARIESCONSOLIDATED STATEMENTS OF CASH FLOWS (In thousands) Year Ended December 31, 2022 2021 2020 Cash flows from operating activities Net income (loss) $ 206,731 $ 1 |
| 21 | 2 | 64 | · Consolidated Statements of Equity | M RESORTS INTERNATIONAL AND SUBSIDIARIESCONSOLIDATED STATEMENTS OF STOCKHOLDERS' EQUITY For the Years ended December 31, 2022, 2021 and 2020 (In thousands) Common Stock Capital in Excessof Par Value R |
| 22 | 2 | 65 | · Notes to Consolidated Financial Statements |  RESORTS INTERNATIONAL AND SUBSIDIARIES NOTES TO CONSOLIDATED FINANCIAL STATEMENTSNOTE 1 — ORGANIZATION Organization. MGM Resorts International, a Delaware corporation, (together with its consolidated |
| 23 | 3 | 65 | · · Note 1. Organization | TES TO CONSOLIDATED FINANCIAL STATEMENTSNOTE 1 — ORGANIZATION Organization. MGM Resorts International, a Delaware corporation, (together with its consolidated subsidiaries, unless otherwise indicated  |
| 24 | 3 | 67 | · · Note 2. Basis Of Presentation And Significant Accounting Policies | VID-19 travelrestrictions were removed. NOTE 2 — BASIS OF PRESENTATION AND SIGNIFICANT ACCOUNTING POLICIES Principles of consolidation. The Company evaluates entities for which control is achieved thr |
| 25 | 3 | 74 | · · Note 3. Accounts Receivable, Net |  cost applied against retainedearnings. NOTE 3 — ACCOUNTS RECEIVABLE, NET Accounts receivable, net consisted of the following: December 31, 2022 2021 (In thousands) Casino $ 500,986 $ 380,907 Hotel 27 |
| 26 | 3 | 75 | · · Note 4. Acquisitions And Divestitures | NOTE 4 — ACQUISITIONS AND DIVESTITURES LeoVegas acquisition. On May 2, 2022, the Company commenced a public offer to the shareholders of LeoVegas to tender 100% |
| 27 | 3 | 79 | · · Note 5. Property And Equipment, Net | lated to assets held for sale $ 539,828 NOTE 5 — PROPERTY AND EQUIPMENT, NET Property and equipment, net consisted of the following: December 31, 2022 2021 (In thousands) Land $ 438,954 $ 4,082,842 Bu |
| 28 | 3 | 79 | · · Note 6. Investments In And Advances To Unconsolidated Affiliates | 50,571 151,909 $ 5,223,928 $ 14,435,493 NOTE 6 — INVESTMENTS IN AND ADVANCES TO UNCONSOLIDATED AFFILIATES Investments in and advances to unconsolidated affiliates consisted of the following: December  |
| 29 | 3 | 81 | · · Note 7. Goodwill And Other Intangible Assets | NOTE 7 — GOODWILL AND OTHER INTANGIBLE ASSETS Goodwill and other intangible assets consisted of the following: December 31, 2022 2021 (In thousands) Goodwill $  |
| 30 | 3 | 82 | · · Note 8. Other Accrued Liabilities | 2027 54,602 Thereafter 59,674 $ 411,761 NOTE 8 — OTHER ACCRUED LIABILITIES Other accrued liabilities consisted of the following: December 31, 2022 2021 (In thousands) Contract and contract-related lia |
| 31 | 3 | 83 | · · Note 9. Long-Term Debt | NOTE 9 — LONG-TERM DEBT Long-term debt consisted of the following: December 31, 2022 2021 (In thousands) MGP OP senior credit facility $ — $ 50,000 MGM China fi |
| 32 | 3 | 86 | · · Note 10. Income Taxes | NOTE 10 — INCOME TAXES The Company recognizes deferred income tax assets, net of applicable reserves, related to net operating losses, tax credit carryforwards  |
| 33 | 3 | 89 | · · Note 11. Leases | elated to its customer loyalty program. NOTE 11 – LEASES The Company leases real estate, land underlying certain of its properties, and various equipment under operating and, to a lesser extent, finan |
| 34 | 3 | 92 | · · Note 12. Commitments And Contingencies | lease liabilities $ 25,149,299 $ 88,181 NOTE 12 – COMMITMENTS AND CONTINGENCIES Litigation. The Company is a party to various legal proceedings, most of which relate to routine matters incidental to i |
| 35 | 3 | 94 | · · Note 13. Stockholders' Equity | NOTE 13 — STOCKHOLDERS' EQUITY Accumulated Other Comprehensive Income (Loss) Changes in accumulated other comprehensive income (loss) attributable to MGM Resort |
| 36 | 3 | 97 | · · Note 14. Stock-Based Compensation | llion. Repurchased shares were retired. NOTE 14 — STOCK-BASED COMPENSATION MGM Resorts International 2022 Omnibus Incentive Plan. On May 4, 2022, the MGM Resorts 2022 Omnibus Incentive Plan ("2022 Omn |
| 37 | 3 | 97 | · · Note 15. Employee Benefit Plans |  tax benefit $ 56,838 $ 51,003 $ 84,233 NOTE 15 — EMPLOYEE BENEFIT PLANS Multiemployer benefit plans. The Company currently participates in multiemployer pension plans in which the risks of participat |
| 38 | 3 | 98 | · · Note 16. Property Transactions, Net | 31, 2022, 2021, and 2020, respectively. NOTE 16 — PROPERTY TRANSACTIONS, NET Property transactions, net consisted of the following: Year Ended December 31, 2022 2021 2020 (In thousands) Gain on sale o |
| 39 | 3 | 98 | · · Note 17. Segment Information | aneous asset disposals and write-downs. NOTE 17 — SEGMENT INFORMATION The Company's management views each of its casino resorts as an operating segment. Operating segments are aggregated based on thei |
| 40 | 3 | 101 | · · Note 18. Related Party Transactions |  $ 36,335,421 $ 33,025,680 $ 28,653,811 NOTE 18 — RELATED PARTY TRANSACTIONS CityCenter Management agreements. Until the Company's acquisition of CityCenter in September 2021, the Company was party to |
| 41 | 1 | 103 | Item 9. Changes in and Disagreements with Accountants on Accounting and Financial Disclosure | ITEM 9. CHANGES IN AND DISAGREEMENTS WITH ACCOUNTANTS ON ACCOUNTING AND FINANCIAL DISCLOSURE None. ITEM 9A. CONTROLS AND PROCEDURES Disclosure Controls and Proc |
| 42 | 1 | 103 | Item 9A. Controls and Procedures | COUNTING AND FINANCIAL DISCLOSURE None. ITEM 9A. CONTROLS AND PROCEDURES Disclosure Controls and Procedures Our Chief Executive Officer (principal executive officer) and Chief Financial Officer (princ |
| 43 | 1 | 104 | Item 9B. Other Information | over financial reporting appearsherein. ITEM 9B. OTHER INFORMATION None. ITEM 9C. DISCLOSURE REGARDING FOREIGN JURISDICTIONS THAT PREVENT INSPECTIONS Not applicable. 101 |
| 44 | 1 | 104 | Item 9C. Disclosure Regarding Foreign Jurisdictions that Prevent Inspections | erein. ITEM 9B. OTHER INFORMATION None. ITEM 9C. DISCLOSURE REGARDING FOREIGN JURISDICTIONS THAT PREVENT INSPECTIONS Not applicable. 101 |
| 45 | 1 | 106 | Item 15. Exhibits and Financial Statement Schedules | PART IV ITEM 15. EXHIBITS, FINANCIAL STATEMENT SCHEDULES (a)(1). Financial Statements. The following consolidated financial statements of the Company are filed as part  |
| 46 | 1 | 111 | Item 16. Form 10-K Summary | h by specific reference in such filing. ITEM 16. FORM 10-K SUMMARY None. 108 |
