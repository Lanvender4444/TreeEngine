# Review: LOCKHEEDMARTIN_2020_10K

source: 10-K schema (semi-automatic, see structures.py) · reviewed: False

## Checklist

- [ ] Heading correctness: every entry is a real heading of this filing (no references, index
      lines, table cells)
- [ ] Heading hierarchy: Items level 1; MD&A subsections, statements, auditor's report and
      Notes level 2; individual notes level 3
- [ ] Page anchor: each page is where the heading is printed (physical page, 1-based)
- [ ] Missing sections: no Item, primary statement or note is missing
- [ ] False-positive sections: nothing listed twice or out of order
- [ ] Notes hierarchy: Note 1..N consecutive, all under "Notes to Consolidated Financial
      Statements"
- [ ] Item boundaries: each Item starts where the previous one ends

## Headings

| # | level | page | title | text on the page |
|---|---|---|---|---|
| 1 | 1 | 3 | Item 1. Business | Table of Contents PART I ITEM 1. Business General We are a global security and aerospace company principally engaged in the research, design, development, manufacture, integration and s |
| 2 | 1 | 8 | Item 1A. Risk Factors | cussion of environmental matters within Item 1A - Risk Factors. Research and Development We conduct research and development (R&D) activities using our own funds (referred to as company-funded R&D or  |
| 3 | 1 | 24 | Item 1B. Unresolved Staff Comments | counting policies and use of estimates. ITEM 1B. Unresolved Staff Comments None. ITEM 2. Properties At December 31, 2020, we owned or leased building space (including offices, manufacturing plants, wa |
| 4 | 1 | 24 | Item 2. Properties | TEM 1B. Unresolved Staff Comments None. ITEM 2. Properties At December 31, 2020, we owned or leased building space (including offices, manufacturing plants, warehouses, service centers, laboratories a |
| 5 | 1 | 25 | Item 3. Legal Proceedings | te to meet the needs of our operations. ITEM 3. Legal Proceedings We are a party to or have property subject to litigation and other proceedings that arise in the ordinary course of our business, incl |
| 6 | 1 | 25 | Item 4. Mine Safety Disclosures | ns also may be audited or investigated. ITEM 4. Mine Safety Disclosures Not applicable. 25 |
| 7 | 1 | 28 | Item 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities | Table of Contents PART II ITEM 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities At January 22, 2021, we had 24,929 holders  |
| 8 | 1 | 30 | Item 6. Selected Financial Data | Table of Contents ITEM 6. Selected Financial Data (In millions, except per share data) 2020 2019 2018 2017 2016 Operating results Net sales $ 65,398 $ 59,812 $ 53,762 $ 49,960 $  |
| 9 | 1 | 32 | Item 7. Management's Discussion and Analysis of Financial Condition and Results of Operations | Table of Contents ITEM 7. Management's Discussion and Analysis of Financial Condition and Results of Operations Business Overview The following Management's Discussion and Analys |
| 10 | 2 | 38 | · Results of Operations | Table of Contents Consolidated Results of Operations Our operating cycle is primarily long term and involves many types of contracts for the design, development and manufacture o |
| 11 | 2 | 54 | · Critical Accounting Estimates | arty guarantees or novation agreements. Critical Accounting Policies Contract Accounting / Sales Recognition The majority of our net sales are generated from long-term contracts with the U.S. Governme |
| 12 | 2 | 57 | · Overview | f Contents Postretirement Benefit Plans Overview Many of our employees and retirees participate in qualified and nonqualified defined benefit pension plans, retiree medical and life insurance plans an |
| 13 | 2 | 62 | · Recent Accounting Pronouncements | ord an impairment loss in net earnings. Recent Accounting Pronouncements See "Note 1 – Significant Accounting Policies" included in our Notes to Consolidated Financial Statements (under the caption "R |
| 14 | 1 | 63 | Item 7A. Quantitative and Qualitative Disclosures About Market Risk | Table of Contents ITEM 7A. Quantitative and Qualitative Disclosures About Market Risk We maintain active relationships with a broad and diverse group of U.S. and international fi |
| 15 | 1 | 64 | Item 8. Financial Statements and Supplementary Data | Table of Contents ITEM 8. Financial Statements and Supplementary Data Report of Independent Registered Public Accounting Firm on the Audited Consolidated Financial Statements Boa |
| 16 | 2 | 64 | · Report of Independent Registered Public Accounting Firm | ncial Statements and Supplementary Data Report of Independent Registered Public Accounting Firm on the Audited Consolidated Financial Statements Board of Directors and Stockholders Lockheed Martin Cor |
| 17 | 2 | 67 | · Consolidated Statements of Income | of Contents Lockheed Martin Corporation Consolidated Statements of Earnings (in millions, except per share data) Years Ended December 31, 2020 2019 2018 Net sales Products $ 54,928 $ 50,053 $ 45,005 S |
| 18 | 2 | 68 | · Consolidated Statements of Comprehensive Income | of Contents Lockheed Martin Corporation Consolidated Statements of Comprehensive Income (in millions) Years Ended December 31, 2020 2019 2018 Net earnings $ 6,833 $ 6,230 $ 5,046 Other comprehensive i |
| 19 | 2 | 69 | · Consolidated Balance Sheets | of Contents Lockheed Martin Corporation Consolidated Balance Sheets (in millions, except par value) December 31, 2020 2019 Assets Current assets Cash and cash equivalents $ 3,160 $ 1,514 Receivables,  |
| 20 | 2 | 70 | · Consolidated Statements of Cash Flows | of Contents Lockheed Martin Corporation Consolidated Statements of Cash Flows (in millions) Years Ended December 31, 2020 2019 2018 Operating activities Net earnings $ 6,833 $ 6,230 $ 5,046 Adjustment |
| 21 | 2 | 71 | · Consolidated Statements of Equity | of Contents Lockheed Martin Corporation Consolidated Statements of Equity (in millions, except per share data) Common Stock Additional Paid-InCapital RetainedEarnings AccumulatedOtherComprehensive Los |
| 22 | 2 | 72 | · Notes to Consolidated Financial Statements | of Contents Lockheed Martin Corporation Notes to Consolidated Financial Statements Note 1 – Significant Accounting Policies Organization – We are a global security and aerospace company principally en |
| 23 | 3 | 72 | · · Note 1. Significant Accounting Policies | es to Consolidated Financial Statements Note 1 – Significant Accounting Policies Organization – We are a global security and aerospace company principally engaged in the research, design, development, |
| 24 | 3 | 80 | · · Note 2. Strategic Action | Table of Contents Note 2 – Strategic Action On December 20, 2020, we announced that we entered into an agreement to acquire Aerojet Rocketdyne Holdings, Inc. (Aerojet Rocketdyne) |
| 25 | 3 | 80 | · · Note 3. Earnings Per Share | esults until the acquisition is closed. Note 3 – Earnings Per Share The weighted average number of shares outstanding used to compute earnings per common share were as follows (in millions): 2020 2019 |
| 26 | 3 | 80 | · · Note 4. Goodwill and Acquired Intangibles | ended December 31, 2020, 2019 and 2018. Note 4 – Goodwill and Acquired Intangibles Changes in the carrying amount of goodwill by segment were as follows (in millions): Aeronautics MFC RMS Space Total  |
| 27 | 3 | 82 | · · Note 5. Information on Business Segments | Table of Contents Note 5 – Information on Business Segments We operate in four business segments: Aeronautics, MFC, RMS and Space. We organize our business segments based on the  |
| 28 | 3 | 86 | · · Note 6. Receivables, net, Contract Assets and Contract Liabilities | d investments held in a separate trust. Note 6 – Receivables, net, Contract Assets and Contract Liabilities Receivables, net, contract assets and contract liabilities were as follows (in millions): 20 |
| 29 | 3 | 87 | · · Note 7. Inventories | 018 and 2017, respectively, as revenue. Note 7 – Inventories Inventories consisted of the following (in millions): 2020 2019 Materials, spares and supplies $ 612 $ 532 Work-in-process 2,693 2,783 Fini |
| 30 | 3 | 87 | · · Note 8. Property, Plant and Equipment, net | act costs were included in inventories. Note 8 – Property, Plant and Equipment, net Property, plant and equipment, net consisted of the following (in millions): 2020 2019 Land $ 142 $ 136 Buildings 7, |
| 31 | 3 | 87 | · · Note 9. Leases | lant and equipment, net $ 7,213 $ 6,591 Note 9 – Leases We evaluate whether our contractual arrangements contain leases at the inception of such arrangements. Specifically, we consider whether we canc |
| 32 | 3 | 88 | · · Note 10. Income Taxes | s: imputed interest $ 158 Total $ 1,115 Note 10 – Income Taxes Our provision for federal and foreign income tax expense for continuing operations consisted of the following (in millions): 2020 2019 20 |
| 33 | 3 | 90 | · · Note 11. Debt | llion in 2020 and $940 million in 2019. Note 11 – Debt Our total debt consisted of the following (in millions): 2020 2019 Notes 2.50% due 2020 $ — $ 1,250 3.35% due 2021 500 900 3.10% due 2023 500 500 |
| 34 | 3 | 91 | · · Note 12. Postretirement Benefit Plans | ity to manage the timing of cash flows. Note 12 – Postretirement Benefit Plans Defined Benefit Pension Plans and Retiree Medical and Life Insurance Plans Many of our employees are covered by qualified |
| 35 | 3 | 94 | · · Note 13. Stockholders' Equity | lion at December 31, 2020 and 2019 (see"Note 13 – Stockholders' Equity") includes $19.8 billion ($15.6 billion, net of tax) and $19.0 billion ($15.0 billion, net of tax) for qualified defined benefit  |
| 36 | 3 | 101 | · · Note 14. Stock-Based Compensation | Table of Contents Note 14 – Stock-Based Compensation During 2020, 2019 and 2018, we recorded non-cash stock-based compensation expense totaling $221 million, $189 million and $17 |
| 37 | 3 | 102 | · · Note 15. Legal Proceedings, Commitments and Contingencies | xpense ratably over the vesting period. Note 15 – Legal Proceedings, Commitments and Contingencies We are a party to or have property subject to litigation and other proceedings that arise in the ordi |
| 38 | 3 | 105 | · · Note 16. Severance Charges | arty guarantees or novation agreements. Note 16 – Severance Charges During 2020, we recorded severance charges totaling $27 million ($21 million, or $0.08 per share, after-tax) related to the planned  |
| 39 | 3 | 105 | · · Note 17. Fair Value Measurements | be paid over the next several quarters. Note 17 – Fair Value Measurements Assets and liabilities measured and recorded at fair value on a recurring basis consisted of the following (in millions): Dece |
| 40 | 3 | 106 | · · Note 18. Summary of Quarterly Information (Unaudited) | Table of Contents Note 18 – Summary of Quarterly Information (Unaudited) A summary of quarterly information is as follows (in millions, except per share data): 2020 Quarters Firs |
| 41 | 1 | 107 | Item 9. Changes in and Disagreements with Accountants on Accounting and Financial Disclosure | Table of Contents ITEM 9. Changes in and Disagreements with Accountants on Accounting and Financial Disclosure None. ITEM 9A. Controls and Procedures Evaluation of Disclosure Con |
| 42 | 1 | 107 | Item 9A. Controls and Procedures | counting and Financial Disclosure None. ITEM 9A. Controls and Procedures Evaluation of Disclosure Controls and Procedures We performed an evaluation of the effectiveness of our disclosure controls and |
| 43 | 1 | 109 | Item 9B. Other Information | Table of Contents ITEM 9B. Other Information None. PART III ITEM 10. Directors, Executive Officers and Corporate Governance The information concerning directors required by Item  |
| 44 | 1 | 109 | Item 10. Directors, Executive Officers and Corporate Governance | EM 9B. Other Information None. PART III ITEM 10. Directors, Executive Officers and Corporate Governance The information concerning directors required by Item 401 of Regulation S-K is included under th |
| 45 | 1 | 109 | Item 11. Executive Compensation | e as permitted by applicable SEC rules. ITEM 11. Executive Compensation The information required by Item 402 of Regulation S-K is included in the text and tables under the captions "Executive Compensa |
| 46 | 1 | 110 | Item 12. Security Ownership of Certain Beneficial Owners and Management and Related Stockholder Matters | Table of Contents ITEM 12. Security Ownership of Certain Beneficial Owners and Management and Related Stockholder Matters The information required by Item 12 related to the secur |
| 47 | 1 | 110 | Item 13. Certain Relationships and Related Transactions, and Director Independence | e numerator) of a dilution calculation. ITEM 13. Certain Relationships and Related Transactions, and Director Independence The information required by Item 404 and 407(a) of Regulation S-K is included |
| 48 | 1 | 110 | Item 14. Principal Accountant Fees and Services | porated by reference in this Form 10-K. ITEM 14. Principal Accounting Fees and Services The information required by this Item 14 is included under the caption "Proposal 2 - Ratification of Appointment |
| 49 | 1 | 111 | Item 15. Exhibits and Financial Statement Schedules | Table of Contents PART IV ITEM 15. Exhibits and Financial Statement Schedules List of financial statements filed as part of this Form 10-K The following financial statements of Lockheed  |
| 50 | 1 | 114 | Item 16. Form 10-K Summary |  or compensatory plans or arrangements. ITEM 16. Form 10-K Summary None. 114 |
