# Review: PFIZER_2021_10K

source: 10-K schema (semi-automatic, see structures.py) · reviewed: False

## Checklist

- [ ] Heading correctness: every entry is a real heading of this filing (no references, index
      lines, table cells)
- [ ] Heading hierarchy: Items level 1; MD&A subsections, statements, auditor's report and
      Notes level 2; individual notes level 3
- [ ] Page anchor: each page is where the heading is printed (physical page, 1-based)
- [ ] Missing sections: no Item, primary statement or note is missing
- [ ] False-positive sections: nothing listed twice or out of order
- [ ] Notes hierarchy: Note 1..N consecutive, all under "Notes to Consolidated Financial
      Statements"
- [ ] Item boundaries: each Item starts where the previous one ends

## Headings

| # | level | page | title | text on the page |
|---|---|---|---|---|
| 1 | 1 | 9 | Item 1. Business | 9and our oral COVID-19 treatment.PART I ITEM 1.BUSINESS ABOUT PFIZERPfizer Inc. is a research-based, global biopharmaceutical company. We apply science and our global resources to bring therapies to p |
| 2 | 1 | 11 | Item 1A. Risk Factors | ion and co-promotion agreements, see theItem 1A. Risk Factors—Collaborations and Other Relationships with Third Parties section in this Form 10-K and Notes 2 and 17.RESEARCH AND DEVELOPMENTR&D is at t |
| 3 | 1 | 29 | Item 2. Properties | dards sections within MD&A and Note 1B .ITEM 2.PROPERTIES We own and lease space globally for sales and marketing, customer service, regulatory compliance, R&D, manufacturing and distribution and corp |
| 4 | 1 | 29 | Item 3. Legal Proceedings | vested in land, buildings and equipment.ITEM 3.LEGAL PROCEEDINGS Certain legal proceedings in which we are involved are discussed in Note 16A .INFORMATION ABOUT OUR EXECUTIVE OFFICERSThe executive off |
| 5 | 1 | 30 | Item 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities | ember 2010. Director of WPP plc.PART II ITEM 5.MARKET FOR THE COMPANY'S COMMON EQUITY, RELATED STOCKHOLDER MATTERS AND ISS UER PURCHASES OFEQUITY SECURITIESThe principal market for our common stock is |
| 6 | 1 | 32 | Item 7. Management's Discussion and Analysis of Financial Condition and Results of Operations | ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND R ESULTS OF OPERATIONSOVERVIEW OF OUR PERFORMANCE, OPERATING ENVIRONMENT, STRATEGY AND O |
| 7 | 2 | 51 | · Cash Flows | LYSIS OF THE CONSOLIDATED STATEMENTS OF CASH FLOWS Cash Flows from Continuing Operations Year Ended December 31, (MILLIONS)2021 2020 2019 Drivers of change Cash provided by/(used in):Operating activit |
| 8 | 1 | 54 | Item 7A. Quantitative and Qualitative Disclosures About Market Risk | on ourconsolidated financial statements.ITEM 7A.QUANTITATIVE AND QUALITATIVE DISCLOSURES ABOUT MARK ET RISKThe information required by this Item is incorporated by reference to the discussion in the A |
| 9 | 1 | 55 | Item 8. Financial Statements and Supplementary Data | ITEM 8. FINANCIAL STATEMENTS AND SUPPLEMENTARY DATAReport of Independent Registered Public Accounting FirmTo the Board of Directors and ShareholdersPfizer Inc.: |
| 10 | 2 | 55 | · Report of Independent Registered Public Accounting Firm | ANCIAL STATEMENTS AND SUPPLEMENTARY DATAReport of Independent Registered Public Accounting FirmTo the Board of Directors and ShareholdersPfizer Inc.:Opinion on the Consolidated Financial StatementsWe  |
| 11 | 2 | 57 | · Consolidated Statements of Income | Consolidated Statements of Income Pfizer Inc. and Subsidiary Companies Year Ended December 31, (MILLIONS, EXCEPT PER COMMON SHARE DATA)2021 2020 2019 Revenues$  |
| 12 | 2 | 58 | · Consolidated Statements of Comprehensive Income | Consolidated Statements of Comprehensive Income Pfizer Inc. and Subsidiary CompaniesYear Ended December 31, (MILLIONS)2021 20202019 Net income before allocation |
| 13 | 2 | 59 | · Consolidated Balance Sheets | Consolidated Balance Sheets Pfizer Inc. and Subsidiary CompaniesAs of December 31, (MILLIONS, EXCEPT PER COMMON SHARE DATA) 2021 2020 AssetsCash and cash equiva |
| 14 | 2 | 60 | · Consolidated Statements of Equity | Consolidated Statements of Equity Pfizer Inc. and Subsidiary Companies PFIZER INC. SHAREHOLDERS Preferred StockCommon Stock Treasury Stock (MILLIONS, EXCEPT PRE |
| 15 | 2 | 61 | · Consolidated Statements of Cash Flows | Consolidated Statements of Cash Flows Pfizer Inc. and Subsidiary Companies Year Ended December 31, (MILLIONS)2021 2020 2019 Operating Activities Net income befo |
| 16 | 2 | 63 | · Notes to Consolidated Financial Statements | Notes to Consolidated Financial Statements Pfizer Inc. and Subsidiary CompaniesNote 1. Basis of Presentation and Significant Accounting PoliciesA. Basis of Pres |
| 17 | 3 | 63 | · · Note 1. Basis of Presentation and Significant Accounting PoliciesA | nts Pfizer Inc. and Subsidiary CompaniesNote 1. Basis of Presentation and Significant Accounting PoliciesA. Basis of PresentationThe consolidated financial statements include the accounts of our paren |
| 18 | 3 | 70 | · · Note 2. Acquisitions, Divestitures, Equity-Method Investments, Licensing Arrangements | d development expenses, as appropriate. Note 2. Acquisitions, Divestitures, Equity-Method Investments, Licensing Arrangements and Collaborative ArrangementsA. AcquisitionsTrilliumOn November 17, 2021, |
| 19 | 3 | 76 | · · Note 3. Restructuring Charges and Other Costs Associated with Acquisitions and | cts under the collaborativearrangements.Note 3. Restructuring Charges and Other Costs Associated with Acquisitions and Cost-Reduction/Productivity InitiativesIn 2019, we substantially completed severa |
| 20 | 3 | 78 | · · Note 4. Other (Income)/Deductions | nts Pfizer Inc. and Subsidiary CompaniesNote 4. Other (Income)/Deductions—NetComponents of Other (income)/deductions––net include: Year Ended December 31, (MILLIONS)2021 2020 2019 Interest income$ (36 |
| 21 | 3 | 78 | · · Note 5. Tax MattersA | t are based on estimates of fair value. Note 5. Tax MattersA. Taxes on Income from Continuing OperationsComponents of Income from continuing operations before provision/(benefit) for taxes on income i |
| 22 | 3 | 82 | · · Note 6. Accumulated Other Comprehensive Loss, Excluding Noncontrolling Interests | at are expected to be held indefinitely.Note 6. Accumulated Other Comprehensive Loss, Excluding Noncontrolling InterestsThe following summarizes the changes, net of tax, in Accumulated other comprehen |
| 23 | 3 | 83 | · · Note 7. Financial InstrumentsA | nts Pfizer Inc. and Subsidiary CompaniesNote 7. Financial InstrumentsA. Fair Value MeasurementsFinancial Assets and Liabilities Measured at Fair Value on a Recurring Basis and Fair Value Hierarchy, us |
| 24 | 3 | 88 | · · Note 8. Other Financial InformationA | uding current portion of long-term debt.Note 8. Other Financial InformationA. InventoriesThe following summarizes the components of Inventories :As of December 31, (MILLIONS)2021 2020 Finished goods$  |
| 25 | 3 | 88 | · · Note 9. Property, Plant and Equipment (PP&E) |  and$25 million as of December 31, 2020.Note 9. Property, Plant and Equipment (PP&E)The following summarizes the components of Property, plant and equipment : Useful Lives As of December 31, (MILLIONS |
| 26 | 3 | 89 | · · Note 10. Identifiable Intangible Assets and GoodwillA | nts Pfizer Inc. and Subsidiary CompaniesNote 10. Identifiable Intangible Assets and GoodwillA. Identifiable Intangible AssetsThe following summarizes the components of Identifiable intangible assets : |
| 27 | 3 | 90 | · · Note 11. Pension and Postretirement Benefit Plans and Defined Contribution Plans | presents the impact of foreign exchange.Note 11. Pension and Postretirement Benefit Plans and Defined Contribution PlansThe majority of our employees worldwide are eligible for retirement benefits pro |
| 28 | 3 | 95 | · · Note 12. EquityA | nts Pfizer Inc. and Subsidiary CompaniesNote 12. EquityA. Common Stock PurchasesWe purchase our common stock through privately negotiated transactions or in the open market as circumstances and prices |
| 29 | 3 | 95 | · · Note 13. Share-Based Payments |  million in 2020and $20 million in 2019.Note 13. Share-Based PaymentsOur compensation programs can include share-based payment awards with value that is determined by reference to the fair value of ou |
| 30 | 3 | 99 | · · Note 14. Earnings Per Common Share Attributable to Pfizer Inc | nts Pfizer Inc. and Subsidiary CompaniesNote 14. Earnings Per Common Share Attributable to Pfizer Inc. Common ShareholdersThe following presents the detailed calculation of EPS: Year Ended December 31 |
| 31 | 3 | 99 | · · Note 15. Leases | hich occurred in May 2020. See Note 12 .Note 15. LeasesWe lease real estate, fleet, and equipment for use in our operations. Our leases generally have lease terms of 1 to 30 years, some of which inclu |
| 32 | 3 | 100 | · · Note 16. Contingencies and Certain Commitments | hs subsequent to the balance sheet date.Note 16. Contingencies and Certain CommitmentsWe and certain of our subsidiaries are subject to numerous contingencies arising in the ordinary course of busines |
| 33 | 3 | 107 | · · Note 17. Segment, Geographic and Other Revenue InformationA | hich the amounts are paidand/or accrued.Note 17. Segment, Geographic and Other Revenue InformationA. Segment InformationWe regularly review our operating segments and the approach used by management t |
| 34 | 1 | 113 | Item 9. Changes in and Disagreements with Accountants on Accounting and Financial Disclosure | may not agree to the total for the year.ITEM 9.CHANGES IN AND DISAGREEMENTS WITH ACCOUNTA NTS ON ACCOUNTING AND FINANCIAL DISCLOSURENone.ITEM 9A.CONTROLS AND PROCEDURES Disclosure Controls and Procedu |
| 35 | 1 | 113 | Item 9A. Controls and Procedures | ACCOUNTING AND FINANCIAL DISCLOSURENone.ITEM 9A.CONTROLS AND PROCEDURES Disclosure Controls and ProceduresAs of the end of the period covered by this Form 10-K, we carried out an evaluation, under the |
| 36 | 1 | 117 | Item 15. Exhibits and Financial Statement Schedules | PART IV ITEM 15.EXHIBITS, FINANCIAL STATEMENT SCHEDULES 15(a)(1) Financial Statements. The following consolidated financial statements, related notes, report of indepen |
| 37 | 1 | 120 | Item 16. Form 10-K Summary | embedded within the Inline XBRLdocument.ITEM 16.FORM 10-K SUMMARY None.Pfizer Inc. 2021 Form 10-K 114 |
