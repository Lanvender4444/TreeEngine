# Review: AMAZON_2019_10K

source: 10-K schema (semi-automatic, see structures.py) · reviewed: False

## Checklist

- [ ] Heading correctness: every entry is a real heading of this filing (no references, index
      lines, table cells)
- [ ] Heading hierarchy: Items level 1; MD&A subsections, statements, auditor's report and
      Notes level 2; individual notes level 3
- [ ] Page anchor: each page is where the heading is printed (physical page, 1-based)
- [ ] Missing sections: no Item, primary statement or note is missing
- [ ] False-positive sections: nothing listed twice or out of order
- [ ] Notes hierarchy: Note 1..N consecutive, all under "Notes to Consolidated Financial
      Statements"
- [ ] Item boundaries: each Item starts where the previous one ends

## Headings

| # | level | page | title | text on the page |
|---|---|---|---|---|
| 1 | 1 | 3 | Item 1. Business | able of Contents AMAZON.COM, INC. PART IItem 1.Business This Annual Report on Form 10-K and the documents incorporated herein by reference contain forward-looking statements based on expectations,esti |
| 2 | 1 | 6 | Item 1A. Risk Factors | Table of Contents Item 1A.Risk Factors Please carefully consider the following discussion of significant factors, events, and uncertainties that make an investment in our securit |
| 3 | 1 | 15 | Item 1B. Unresolved Staff Comments | negatively affect our operating results.Item 1B.Unresolved Staff Comments None.15 |
| 4 | 1 | 16 | Item 2. Properties | Table of Contents Item 2.Properties As of December 31, 2019, we operated the following fa cilities (in thousands): Description of Use Leased SquareFootage (1) Owned Square Footag |
| 5 | 1 | 16 | Item 3. Legal Proceedings | tle, Washington and Arlington, Virginia.Item 3.Legal Proceedings See Item 8 of Part II, "Financial Statements and Supplementary Data — Note 7 — Commitments and Contingencies — Legal Proceedings."Item  |
| 6 | 1 | 17 | Item 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities | Table of Contents PART II Item 5.Market for the Registrant's Common Stock, Related Shareholder Mat ters, and Issuer Purchases of Equity SecuritiesMarket InformationOur common stock is tr |
| 7 | 1 | 18 | Item 6. Selected Financial Data | Table of Contents Item 6.Selected Consolidated Financial Data The following selected consolidated financial data should be read in conjunction with the consolidated financial sta |
| 8 | 1 | 19 | Item 7. Management's Discussion and Analysis of Financial Condition and Results of Operations | Table of Contents Item 7.Management's Discussion and Analysis of Financial Condition and Results of Operations Forward-Looking StatementsThis Annual Report on Form 10-K includes  |
| 9 | 1 | 32 | Item 7A. Quantitative and Qualitative Disclosures About Market Risk | Table of Contents Item 7A.Quantitative and Qualitative Disclosures About Market Risk We are exposed to market risk for the effect of interest rate changes, foreign currency fluct |
| 10 | 1 | 34 | Item 8. Financial Statements and Supplementary Data | Table of Contents Item 8.Financial Statements and Supplementary Data INDEX TO CONSOLIDATED F INANCIAL STATEMENTS Page Report of Ernst & Young LLP, Independent Registered Public A |
| 11 | 2 | 34 | · Consolidated Statements of Cash Flows | ent Registered Public Accounting Firm35 Consolidated Statements of Cash Flows37 Consolidated Statements of Operations38 Consolidated Statements of Comprehensive Income39 Consolidated Balance Sheets40  |
| 12 | 2 | 34 | · Consolidated Statements of Income | Consolidated Statements of Cash Flows37 Consolidated Statements of Operations38 Consolidated Statements of Comprehensive Income39 Consolidated Balance Sheets40 Consolidated Statements of Stockholders' |
| 13 | 2 | 35 | · Report of Independent Registered Public Accounting Firm | Table of Contents Report of Independent Registered Public Accounting Firm The Board of Directors and ShareholdersAmazon.com, Inc.Opinion on the Financial StatementsWe have audite |
| 14 | 2 | 39 | · Consolidated Statements of Comprehensive Income | Table of Contents AMAZON.COM, INC. CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME(in millions) Year Ended December 31, 2017 2018 2019Net income$ 3,033 $10,073 $11,588Other comprehensive income ( |
| 15 | 2 | 40 | · Consolidated Balance Sheets | Table of Contents AMAZON.COM, INC. CONSOLIDATED BALANCE SHEETS(in millions, except per share data) December 31, 2018 2019ASSETS Current assets: Cash and cash equivalents$ 31,750 $36,092Marketable |
| 16 | 2 | 41 | · Consolidated Statements of Equity | Table of Contents AMAZON.COM, INC. CONSOLIDATED STATEMENTS OF STOCKHOLDERS' EQUITY(in millions) Common Stock Shares Amount TreasuryStock AdditionalPaid-InCapital Accumulated OtherComprehensiveInc |
| 17 | 2 | 42 | · Notes to Consolidated Financial Statements | Table of Contents AMAZON.COM, INC. NOTES TO CONSOLIDATED FINANCIAL STATEMENTSNote 1 — DESCRIPTION OF BUSINESS AND ACCOUNTING POLICIESDescription of BusinessWe seek to be Earth's most customer-cen |
| 18 | 3 | 42 | · · Note 1. Description Of Business And Accounting Policies | TES TO CONSOLIDATED FINANCIAL STATEMENTSNote 1 — DESCRIPTION OF BUSINESS AND ACCOUNTING POLICIESDescription of BusinessWe seek to be Earth's most customer-centric company. In each of our segments, we  |
| 19 | 3 | 51 | · · Note 2. Financial Instruments | Table of Contents Note 2 — FINANCIAL INSTRUMENTSCash, Cash Equivalents, Restricted Cash, and Marketable SecuritiesAs of December 31, 2018 and 2019, our cash, cash equivalents, re |
| 20 | 3 | 53 | · · Note 3. Property And Equipment | tatements of cash flows$ 32,173 $36,410 Note 3 — PROPERTY AND EQUIPMENTProperty and equipment, at cost, consisted of the following (in millions): December 31, 2018 2019Gross property and equipment (1) |
| 21 | 3 | 53 | · · Note 4. Leases |  $10.1 billion for 2017, 2018, and 2019.Note 4 — LEASESGross assets acquired under finance leases, inclusive of those where title transfers at the end of the lease, are recorded in "Property and equip |
| 22 | 3 | 54 | · · Note 5. Acquisitions, Goodwill, And Acquired Intangible Assets2017 | ease liabilities$ 22,696 $17,095 $39,791Note 5 — ACQUISITIONS, GOODWILL, AND ACQUIRED INTANGIBLE ASSETS2017 Acquisition ActivityOn May 12, 2017, we acquired Souq Group Ltd., an e-commerce company, for |
| 23 | 3 | 57 | · · Note 6. Debt | Table of Contents Note 6 — DEBTAs of December 31, 2019, we had $23.3 billion of unsecured senior notes outstanding (the "Notes"). As of December 31, 2018 and 2019, the netunamort |
| 24 | 3 | 59 | · · Note 7. Commitments And Contingencies | Table of Contents Note 7 — COMMITMENTS AND CONTINGENCIESCommitmentsWe have entered into non-cancellable operating and finance leases and financing obligations for equipment and o |
| 25 | 3 | 62 | · · Note 8. Stockholders' Equity | medies.See also "Note 9 — Income Taxes."Note 8 — STOCKHOLDERS' EQUITYPreferred StockWe have authorized 500 million shares of $0.01 par value preferred stock. No preferred stock was outstanding for any |
| 26 | 3 | 63 | · · Note 9. Income Taxes | ance to employees is 108 million shares.Note 9 — INCOME TAXESIn 2017, 2018, and 2019, we recorded net tax provisions of $769 million , $1.2 billion, and $2.4 billion. Tax benefits relating to excess s |
| 27 | 3 | 66 | · · Note 10. Segment Information | imate of the range of possible outcomes.Note 10 — SEGMENT INFORMATIONWe have organized our operations into three segments: North America, International, and AWS. We allocate to segment results the ope |
| 28 | 3 | 70 | · · Note 11. Quarterly Results (Unaudited) | Table of Contents Note 11 — QUARTERLY RESULTS (UNAUDITED)The following tables contain selected unaudited statement of operations information for each quarter of 2018 and 2019. Th |
| 29 | 1 | 71 | Item 9. Changes in and Disagreements with Accountants on Accounting and Financial Disclosure | Table of Contents Item 9.Changes in and Disagreements with Accountants On Accounting and Financial Disclosure None.Item 9A.Controls and Procedures Evaluation of Disclosure Contro |
| 30 | 1 | 71 | Item 9A. Controls and Procedures | ccounting and Financial Disclosure None.Item 9A.Controls and Procedures Evaluation of Disclosure Controls and ProceduresWe carried out an evaluation required by the Securities Exchange Act of 1934 (th |
| 31 | 1 | 75 | Item 16. Form 10-K Summary | xecutive Compensation Plan or Agreement.Item 16.Form 10-K SummaryNone.75 |
