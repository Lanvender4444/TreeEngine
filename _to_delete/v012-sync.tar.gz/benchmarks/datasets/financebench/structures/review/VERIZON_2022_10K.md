# Review: VERIZON_2022_10K

source: 10-K schema (semi-automatic, see structures.py) · reviewed: False

## Checklist

- [ ] Heading correctness: every entry is a real heading of this filing (no references, index
      lines, table cells)
- [ ] Heading hierarchy: Items level 1; MD&A subsections, statements, auditor's report and
      Notes level 2; individual notes level 3
- [ ] Page anchor: each page is where the heading is printed (physical page, 1-based)
- [ ] Missing sections: no Item, primary statement or note is missing
- [ ] False-positive sections: nothing listed twice or out of order
- [ ] Notes hierarchy: Note 1..N consecutive, all under "Notes to Consolidated Financial
      Statements"
- [ ] Item boundaries: each Item starts where the previous one ends

## Headings

| # | level | page | title | text on the page |
|---|---|---|---|---|
| 1 | 1 | 4 | Item 1. Business | PART I Item 1. Business General Verizon Communications Inc. (the Company) is a holding company that, acting through its subsidiaries (together with the Company, collec |
| 2 | 1 | 14 | Item 1A. Risk Factors |  could result in an impact on earnings. Item 1A. Risk Factors The following discussion of "Risk Factors" identifies factors that may adversely affect our business, operations, financial condition or f |
| 3 | 1 | 19 | Item 2. Properties | Item 2. Properties Our principal properties do not lend themselves to simple description by character and location. Our total gross investment in property, plan |
| 4 | 1 | 19 | Item 3. Legal Proceedings | in process, and leasehold improvements. Item 3. Legal Proceedings In the ordinary course of business, Verizon is involved in various litigation and regulatory proceedings at the state and federal leve |
| 5 | 1 | 19 | Item 4. Mine Safety Disclosures | n risks, refer to Item 1A Risk Factors. Item 4. Mine Safety Disclosures None. 19 Verizon 2022 Annual Report on Form 10-K |
| 6 | 1 | 20 | Item 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities | PART II Item 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities The principal market for trading in the com |
| 7 | 1 | 21 | Item 7. Management's Discussion and Analysis of Financial Condition and Results of Operations | Item 7. Management's Discussion and Analysis of Financial Condition and Results of Operations Overview Verizon Communications Inc. (the Company) is a holding co |
| 8 | 2 | 21 | · Overview | ial Condition and Results of Operations Overview Verizon Communications Inc. (the Company) is a holding company that, acting through its subsidiaries (together with the Company, collectively, Verizon) |
| 9 | 2 | 23 | · Results of Operations | assessment of segment performance. See "Consolidated Results of Operations" for additional information regarding Corporate and other results. Capital Expenditures and Investments We continue to invest |
| 10 | 2 | 37 | · Liquidity and Capital Resources | Cash Flows from Financing Activities"). Liquidity and Capital Resources We use the net cash generated from our operations to fund expansion and modernization of our networks, service and repay externa |
| 11 | 2 | 43 | · Critical Accounting Estimates | nd Recently Issued Accounting Standards Critical Accounting Estimates A summary of the critical accounting estimates used in preparing our financial statements are as follows: Wireless Licenses and Go |
| 12 | 1 | 48 | Item 7A. Quantitative and Qualitative Disclosures About Market Risk | e for the year ended December 31, 2021. Item 7A. Quantitative and Qualitative Disclosures About Market Risk We are exposed to various types of market risk in the normal course of business, including t |
| 13 | 1 | 51 | Item 8. Financial Statements and Supplementary Data | Item 8. Financial Statements and Supplementary Data Report of Independent Registered Public Accounting Firm To the Shareholders and the Board of Directors of Ve |
| 14 | 2 | 51 | · Report of Independent Registered Public Accounting Firm | ncial Statements and Supplementary Data Report of Independent Registered Public Accounting Firm To the Shareholders and the Board of Directors of Verizon Communications Inc.: Opinion on Internal Contr |
| 15 | 2 | 54 | · Consolidated Statements of Income | Consolidated Statements of Income Verizon Communications Inc. and Subsidiaries (dollars in millions, except per share amounts) Years Ended December 31, 2022 202 |
| 16 | 2 | 55 | · Consolidated Statements of Comprehensive Income | Consolidated Statements of Comprehensive Income Verizon Communications Inc. and Subsidiaries (dollars in millions) Years Ended December 31, 2022 2021 2020 Net I |
| 17 | 2 | 56 | · Consolidated Balance Sheets | Consolidated Balance Sheets Verizon Communications Inc. and Subsidiaries (dollars in millions, except per share amounts) At December 31, 2022 2021 Assets Curren |
| 18 | 2 | 57 | · Consolidated Statements of Cash Flows | Consolidated Statements of Cash Flows Verizon Communications Inc. and Subsidiaries (dollars in millions) Years Ended December 31, 2022 2021 2020 Cash Flows from |
| 19 | 2 | 58 | · Consolidated Statements of Equity | Consolidated Statements of Changes in Equity Verizon Communications Inc. and Subsidiaries (dollars in millions, except per share amounts, and shares in thousand |
| 20 | 2 | 59 | · Notes to Consolidated Financial Statements | Notes to Consolidated Financial Statements Verizon Communications Inc. and Subsidiaries Note 1. Description of Business and Summary of Significant Accounting Po |
| 21 | 3 | 59 | · · Note 1. Description of Business and Summary of Significant Accounting Policies | on Communications Inc. and Subsidiaries Note 1. Description of Business and Summary of Significant Accounting Policies Description of Business Verizon Communications Inc. (the Company) is a holding co |
| 22 | 3 | 67 | · · Note 2. Revenue and Contract Costs | g disclosures required under Topic 326. Note 2. Revenue and Contract Costs We earn revenue from contracts with customers, primarily through the provision of telecommunications and other services and t |
| 23 | 3 | 70 | · · Note 3. Acquisitions and Divestitures | years ended December 31, 2022 and 2021. Note 3. Acquisitions and Divestitures Spectrum License Transactions In March 2020, the FCC's incentive auction, Auction 103, for spectrum licenses in the upper  |
| 24 | 3 | 72 | · · Note 4. Wireless Licenses, Goodwill and Other Intangible Assets | e for the year ended December 31, 2021. Note 4. Wireless Licenses, Goodwill and Other Intangible Assets Wireless Licenses The carrying amounts of Wireless licenses are as follows: (dollars in millions |
| 25 | 3 | 74 | · · Note 5. Property, Plant and Equipment |  2,256 2025 2,059 2026 1,813 2027 1,260 Note 5. Property, Plant and Equipment The following table displays the details of Property, plant and equipment, which is stated at cost: (dollars in millions)  |
| 26 | 3 | 74 | · · Note 6. Leasing Arrangements | t and equipment, net $ 107,434 $ 99,696 Note 6. Leasing Arrangements We enter into various lease arrangements for network equipment including towers, distributed antenna systems, small cells, real est |
| 27 | 3 | 77 | · · Note 7. Debt | Note 7. Debt Outstanding long-term debt obligations as of December 31, 2022 and 2021 are as follows: (dollars in millions) At December 31, Maturities Interest R |
| 28 | 3 | 82 | · · Note 8. Device Payment Plan Agreement and Wireless Service Receivables | ctive covenants in our debt agreements. Note 8. Device Payment Plan Agreement and Wireless Service Receivables The following table presents information about accounts receivable, net of allowances, re |
| 29 | 3 | 86 | · · Note 9. Fair Value Measurements and Financial Instruments | Note 9. Fair Value Measurements and Financial Instruments Recurring Fair Value Measurements The following table presents the balances of assets and liabilities  |
| 30 | 3 | 90 | · · Note 10. Stock-Based Compensation | our diversified pool of counterparties. Note 10. Stock-Based Compensation Verizon Long-Term Incentive Plan In May 2017, our shareholders approved the 2017 Long-Term Incentive Plan (the 2017 Plan) and  |
| 31 | 3 | 92 | · · Note 11. Employee Benefits | Note 11. Employee Benefits We maintain non-contributory defined benefit pension plans for certain employees. In addition, we maintain postretirement health care |
| 32 | 3 | 98 | · · Note 12. Taxes |  our consolidated statements of income. Note 12. Taxes The components of income before provision for income taxes are as follows: (dollars in millions) Years Ended December 31, 2022 2021 2020 Domestic |
| 33 | 3 | 100 | · · Note 13. Segment Information | ters are further developed or resolved. Note 13. Segment Information Reportable Segments We have two reportable segments that we operate and manage as strategic business units - Consumer and Business. |
| 34 | 3 | 103 | · · Note 14. Equity and Comprehensive Income (Loss) | al reportable segment operating income. Note 14. Equity and Comprehensive Income (Loss) Equity Common Stock In February 2020, the Board of Directors of the Company authorized a share buyback program t |
| 35 | 3 | 105 | · · Note 15. Additional Financial Information | Note 15. Additional Financial Information The following tables provide additional financial information related to our consolidated financial statements: Income |
| 36 | 3 | 106 | · · Note 16. Commitments and Contingencies |  settlements of associated instruments. Note 16. Commitments and Contingencies In the ordinary course of business, Verizon is involved in various commercial litigation and regulatory proceedings at th |
| 37 | 1 | 107 | Item 9. Changes in and Disagreements with Accountants on Accounting and Financial Disclosure | ices as needed with no firm commitment. Item 9. Changes in and Disagreements with Accountants on Accounting and Financial Disclosure None. Item 9A. Controls and Procedures Evaluation of Disclosure Con |
| 38 | 1 | 107 | Item 9A. Controls and Procedures | counting and Financial Disclosure None. Item 9A. Controls and Procedures Evaluation of Disclosure Controls and Procedures Our Chief Executive Officer and Chief Financial Officer have evaluated the eff |
| 39 | 1 | 107 | Item 9B. Other Information | cluded in Item 8 of this Annual Report. Item 9B. Other Information None. Item 9C. Disclosure Regarding Foreign Jurisdictions that Prevent Inspections Not applicable. 107 Verizon 2022 Annual Report on  |
| 40 | 1 | 107 | Item 9C. Disclosure Regarding Foreign Jurisdictions that Prevent Inspections | eport. Item 9B. Other Information None. Item 9C. Disclosure Regarding Foreign Jurisdictions that Prevent Inspections Not applicable. 107 Verizon 2022 Annual Report on Form 10-K |
| 41 | 1 | 108 | Item 10. Directors, Executive Officers and Corporate Governance | PART III Item 10. Directors, Executive Officers and Corporate Governance Set forth below is information with respect to our current executive officers. Name Age Office H |
| 42 | 1 | 108 | Item 11. Executive Compensation | h are incorporated herein by reference. Item 11. Executive Compensation For information with respect to executive compensation, see the sections entitled "Governance — Non-employee Director compensati |
| 43 | 1 | 108 | Item 12. Security Ownership of Certain Beneficial Owners and Management and Related Stockholder Matters | h (e)(4) of Item 407 of Regulation S-K. Item 12. Security Ownership of Certain Beneficial Owners and Management and Related Stockholder Matters For information with respect to the security ownership o |
| 44 | 1 | 109 | Item 13. Certain Relationships and Related Transactions, and Director Independence | permitted to be issued under this plan. Item 13. Certain Relationships and Related Transactions, and Director Independence For information with respect to certain relationships and related transaction |
| 45 | 1 | 109 | Item 14. Principal Accountant Fees and Services | h are incorporated herein by reference. Item 14. Principal Accounting Fees and Services Our independent registered public accounting firm is Ernst & Young LLP , New York, NY , Auditor Firm ID: 42. For |
| 46 | 1 | 110 | Item 15. Exhibits and Financial Statement Schedules | PART I V Item 15. Exhibits and Financial Statement Schedules (a) Documents filed as part of this report: Page (1) Financial Statements Report of Independent Registered P |
| 47 | 1 | 114 | Item 16. Form 10-K Summary | Item 16. Form 10-K Summary None. Signatures Pursuant to the requirements of Section 13 or 15(d) of the Securities Exchange Act of 1934, the registrant has duly  |
