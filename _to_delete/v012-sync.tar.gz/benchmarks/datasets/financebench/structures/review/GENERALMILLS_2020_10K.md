# Review: GENERALMILLS_2020_10K

source: 10-K schema (semi-automatic, see structures.py) · reviewed: False

## Checklist

- [ ] Heading correctness: every entry is a real heading of this filing (no references, index
      lines, table cells)
- [ ] Heading hierarchy: Items level 1; MD&A subsections, statements, auditor's report and
      Notes level 2; individual notes level 3
- [ ] Page anchor: each page is where the heading is printed (physical page, 1-based)
- [ ] Missing sections: no Item, primary statement or note is missing
- [ ] False-positive sections: nothing listed twice or out of order
- [ ] Notes hierarchy: Note 1..N consecutive, all under "Notes to Consolidated Financial
      Statements"
- [ ] Item boundaries: each Item starts where the previous one ends

## Headings

| # | level | page | title | text on the page |
|---|---|---|---|---|
| 1 | 1 | 4 | Item 1. Business | 4 PART I ITEM 1 - Business General Mills, Inc. was incorporated in Delaware in 1928. The terms "General Mills," "Company," "registrant," "we," "us," and "our" mean Gener |
| 2 | 1 | 9 | Item 1A. Risk Factors | 9 ITEM 1A - Risk Factors Our business is subject to various risks and uncertainties. Any of the risks described below could materially, adversely affect our busin |
| 3 | 1 | 15 | Item 1B. Unresolved Staff Comments |  acquisition-related intangible assets. ITEM 1B - Unresolved Staff Comments None. ITEM 2 - Properties We own our principal executive offices and main research facilities, which are located in the Minn |
| 4 | 1 | 15 | Item 2. Properties | EM 1B - Unresolved Staff Comments None. ITEM 2 - Properties We own our principal executive offices and main research facilities, which are located in the Minneapolis, Minnesota metropolitan area. We o |
| 5 | 1 | 16 | Item 3. Legal Proceedings | 16 ITEM 3 - Legal Proceedings We are the subject of various pending or threatened legal actions in the ordinary course of our business. All such matters are subjec |
| 6 | 1 | 16 | Item 4. Mine Safety Disclosures | ental matters in which we are involved. ITEM 4 - Mine Safety Disclosures None. PART II ITEM 5 - Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securi |
| 7 | 1 | 16 | Item 5. Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities | - Mine Safety Disclosures None. PART II ITEM 5 - Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities Our common stock is listed on the New York |
| 8 | 1 | 17 | Item 6. Selected Financial Data | 17 ITEM 6 - Selected Financial Data The following table sets forth selected financial data for each of the fiscal years in the five-year period ended May 31, 2020: |
| 9 | 1 | 18 | Item 7. Management's Discussion and Analysis of Financial Condition and Results of Operations | 18 ITEM 7 - Management's Discussion and Analysis of Financial Condition and Results of Operations EXECUTIVE OVERVIEW We are a global packaged foods company. We dev |
| 10 | 2 | 18 | · Overview | ial Condition and Results of Operations EXECUTIVE OVERVIEW We are a global packaged foods company. We develop distinctive value-added food products and market them under unique brand names. We work co |
| 11 | 2 | 19 | · Results of Operations | elow in the section titled "Fiscal 2020 Consolidated Results of Operations." A detailed review of our fiscal 2019 performance compared to our fiscal 2018 performance is set forth in Part II, Item 7 of |
| 12 | 2 | 30 | · Contractual Obligations | iod. OFF-BALANCE SHEET ARRANGEMENTS AND CONTRACTUAL OBLIGATIONS As of May 31, 2020, we have issued guarantees and comfort letters of $130 million for the debt and other obligations of non-consolidated |
| 13 | 2 | 35 | · Recent Accounting Pronouncements | 35 RECENTLY ISSUED ACCOUNTING PRONOUNCEMENTS In March 2020, the Financial Accounting Standards Board (FASB) issued optional accounting guidance for a limited perio |
| 14 | 2 | 35 | · Non-GAAP Financial Measures | ts of operations or financial position. NON-GAAP MEASURES We have included in this report measures of financial performance that are not defined by GAAP. We believe that these measures provide useful  |
| 15 | 1 | 43 | Item 7A. Quantitative and Qualitative Disclosures About Market Risk | of anticipated or unanticipated events. ITEM 7A - Quantitative and Qualitative Disclosures About Market Risk We are exposed to market risk stemming from changes in interest and foreign exchange rates  |
| 16 | 1 | 45 | Item 8. Financial Statements and Supplementary Data | 45 ITEM 8 - Financial Statements and Supplementary Data REPORT OF MANAGEMENT RESPONSIBILITIES The management of General Mills, Inc. is responsible for the fairness |
| 17 | 2 | 46 | · Report of Independent Registered Public Accounting Firm | 46 Report of Independent Registered Public Accounting Firm To the Stockholders and Board of Directors General Mills, Inc.: Opinions on the Consolidated Financial S |
| 18 | 2 | 48 | · Consolidated Statements of Income | 48 Consolidated Statements of Earnings GENERAL MILLS, INC. AND SUBSIDIARIES (In Millions, Except per Share Data) Fiscal Year 2020 2019 2018 Net sales $ 17,626.6 $  |
| 19 | 2 | 49 | · Consolidated Statements of Comprehensive Income | 49 Consolidated Statements of Comprehensive Income GENERAL MILLS, INC. AND SUBSIDIARIES (In Millions) Fiscal Year 2020 2019 2018 Net earnings, including earnings a |
| 20 | 2 | 50 | · Consolidated Balance Sheets | 50 Consolidated Balance Sheets GENERAL MILLS, INC. AND SUBSIDIARIES (In Millions, Except Par Value) May 31, 2020 May 26, 2019 ASSETS Current assets: Cash and cash  |
| 21 | 2 | 52 | · Consolidated Statements of Cash Flows | 52 Consolidated Statements of Cash Flows GENERAL MILLS, INC. AND SUBSIDIARIES (In Millions) Fiscal Year 2020 2019 2018 Cash Flows - Operating Activities Net earnin |
| 22 | 2 | 53 | · Notes to Consolidated Financial Statements | 53 Notes to Consolidated Financial Statements GENERAL MILLS, INC. AND SUBSIDIARIES NOTE 1. BASIS OF PRESENTATION AND RECLASSIFICATIONS Basis of Presentation Our Co |
| 23 | 3 | 53 | · · Note 1. Basis Of Presentation And Reclassifications | ts GENERAL MILLS, INC. AND SUBSIDIARIES NOTE 1. BASIS OF PRESENTATION AND RECLASSIFICATIONS Basis of Presentation Our Consolidated Financial Statements include the accounts of General Mills, Inc. and  |
| 24 | 3 | 53 | · · Note 2. Summary Of Significant Accounting Policies | usiness is on an April fiscal year end. NOTE 2. SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES Cash and Cash Equivalents We consider all investments purchased with an original maturity of three months or  |
| 25 | 3 | 57 | · · Note 3. Divestitures | ts of operations or financial position. NOTE 3. DIVESTITURES During the third quarter of fiscal 2019, we sold our La Salteña fresh pasta and refrigerated dough business in Argentina, and recorded a pr |
| 26 | 3 | 58 | · · Note 4. Restructuring, Impairment, And Other Exit Costs | 58 NOTE 4. RESTRUCTURING, IMPAIRMENT, AND OTHER EXIT COSTS ASSET IMPAIRMENTS In fiscal 2019, we recorded a $192.6 million charge related to the impairment of our P |
| 27 | 3 | 59 | · · Note 5. Investments In Unconsolidated Joint Ventures | ves on our Consolidated Balance Sheets. NOTE 5. INVESTMENTS IN UNCONSOLIDATED JOINT VENTURES We have a 50 percent interest in Cereal Partners Worldwide (CPW), which manufactures and markets ready-to-e |
| 28 | 3 | 60 | · · Note 6. Goodwill And Other Intangible Assets | 517.3 Noncurrent liabilities 104.2 77.1 NOTE 6. GOODWILL AND OTHER INTANGIBLE ASSETS The components of goodwill and other intangible assets are as follows: In Millions May 31, 2020 May 26, 2019 Goodwi |
| 29 | 3 | 62 | · · Note 7. Leases | e cost of capital rates, and tax rates. NOTE 7. LEASES Our lease portfolio primarily consists of operating lease arrangements for certain warehouse and distribution space, office space, retail shops,  |
| 30 | 3 | 63 | · · Note 8. Financial Instruments, Risk Management Activities, And Fair Values | change for new lease liabilities $ 46.3 NOTE 8. FINANCIAL INSTRUMENTS, RISK MANAGEMENT ACTIVITIES, AND FAIR VALUES FINANCIAL INSTRUMENTS The carrying values of cash and cash equivalents, receivables,  |
| 31 | 3 | 71 | · · Note 9. Debt | 71 NOTE 9. DEBT NOTES PAYABLE The components of notes payable and their respective weighted-average interest rates at the end of the periods were as follows: May 3 |
| 32 | 3 | 72 | · · Note 10. Redeemable And Noncontrolling Interests | al 2021 is a $9.4 million pre-tax loss. NOTE 10. REDEEMABLE AND NONCONTROLLING INTERESTS Our principal redeemable and noncontrolling interests relate to our Yoplait SAS, Yoplait Marques SNC, Liberté M |
| 33 | 3 | 73 | · · Note 11. Stockholders' Equity | compliance with all of these covenants. NOTE 11. STOCKHOLDERS' EQUITY Cumulative preference stock of 5.0 million shares, without par value, is authorized but unissued. On May 6, 2014, our Board of Dir |
| 34 | 3 | 75 | · · Note 12. Stock Plans | see Note 15 for additional information. NOTE 12. STOCK PLANS We use broad-based stock plans to help ensure that management's interests are aligned with those of our shareholders. As of May 31, 2020, a |
| 35 | 3 | 78 | · · Note 13. Earnings Per Share | 78 NOTE 13. EARNINGS PER SHARE Basic and diluted EPS were calculated using the following: Fiscal Year In Millions, Except per Share Data 2020 2019 2018 Net earning |
| 36 | 3 | 78 | · · Note 14. Retirement Benefits And Postemployment Benefits | nd performance share units 8.4 14.1 8.9 NOTE 14. RETIREMENT BENEFITS AND POSTEMPLOYMENT BENEFITS Defined Benefit Pension Plans We have defined benefit pension plans covering many employees in the Unit |
| 37 | 3 | 85 | · · Note 15. Income Taxes | , 2020, and May 26, 2019, respectively. NOTE 15. INCOME TAXES The components of earnings before income taxes and after-tax earnings from joint ventures and the corresponding income taxes thereon are a |
| 38 | 3 | 88 | · · Note 16. Commitments And Contingencies | erest and penalties as of May 26, 2019. NOTE 16. COMMITMENTS AND CONTINGENCIES As of May 31, 2020, we have issued guarantees and comfort letters of $129.8 million for the debt and other obligations of |
| 39 | 3 | 88 | · · Note 17. Business Segment And Geographic Information | ded a loss contingency for this matter. NOTE 17. BUSINESS SEGMENT AND GEOGRAPHIC INFORMATION We operate in the packaged foods industry. Our operating segments are as follows: North America Retail; Con |
| 40 | 3 | 91 | · · Note 18. Supplemental Information | s 819.0 914.4 Total $ 3,580.6 $ 3,787.2 NOTE 18. SUPPLEMENTAL INFORMATION The components of certain Consolidated Balance Sheet accounts are as follows: In Millions May 31, 2020 May 26, 2019 Receivable |
| 41 | 3 | 93 | · · Note 19. Quarterly Data (Unaudited) | paid for income taxes 403.3 440.8 489.4 NOTE 19. QUARTERLY DATA (UNAUDITED) Summarized quarterly data for fiscal 2020 and fiscal 2019 follows: First Quarter Second Quarter Third Quarter Fourth Quarter |
| 42 | 1 | 97 | Item 9. Changes in and Disagreements with Accountants on Accounting and Financial Disclosure |  as of the last day of our fiscal year. ITEM 9 - Changes in and Disagreements With Accountants on Accounting and Financial Disclosure None. ITEM 9A Controls and Procedures We, under the supervision an |
| 43 | 1 | 97 | Item 9A. Controls and Procedures | counting and Financial Disclosure None. ITEM 9A Controls and Procedures We, under the supervision and with the participation of our management, including our Chief Executive Officer and Chief Financia |
| 44 | 1 | 98 | Item 9B. Other Information | ounting Firm" in Item 8 of this report. ITEM 9B - Other Information None. PART III ITEM 10 - Directors, Executive Officers and Corporate Governance The information contained in the sections entitled " |
| 45 | 1 | 98 | Item 10. Directors, Executive Officers and Corporate Governance | M 9B - Other Information None. PART III ITEM 10 - Directors, Executive Officers and Corporate Governance The information contained in the sections entitled "Proposal Number 1 - Election of Directors," |
| 46 | 1 | 98 | Item 11. Executive Compensation | Code of Conduct for principal officers. ITEM 11 - Executive Compensation The information contained in the sections entitled "Executive Compensation," "Director Compensation," and "Overseeing Risk Mana |
| 47 | 1 | 98 | Item 12. Security Ownership of Certain Beneficial Owners and Management and Related Stockholder Matters | rs is incorporated herein by reference. ITEM 12 - Security Ownership of Certain Beneficial Owners and Management and Related Stockholder Matters The information contained in the section entitled "Owne |
| 48 | 1 | 99 | Item 13. Certain Relationships and Related Transactions, and Director Independence | es available for grant at May 31, 2020. ITEM 13 - Certain Relationships and Related Transactions, and Director Independence The information set forth in the section entitled "Board Independence and Re |
| 49 | 1 | 99 | Item 14. Principal Accountant Fees and Services | rs is incorporated herein by reference. ITEM 14 - Principal Accounting Fees and Services The information contained in the section entitled "Independent Registered Public Accounting Firm Fees" in our d |
| 50 | 1 | 100 | Item 15. Exhibits and Financial Statement Schedules | 100 PART IV ITEM 15 – Exhibits and Financial Statement Schedules 1. Financial Statements: The following financial statements are included in Item 8 of this report: Consolid |
| 51 | 1 | 103 | Item 16. Form 10-K Summary | furnish copies to the SEC upon request. ITEM 16 - Form 10-K Summary Not Applicable. |
